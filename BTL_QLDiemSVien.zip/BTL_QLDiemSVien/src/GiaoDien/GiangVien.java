package GiaoDien;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
public class GiangVien extends javax.swing.JFrame {
private String maGV;



    public GiangVien() {
        initComponents();
        loadThongTinGiangVien(maGV);
        this.maGV = maGV;
    }
public GiangVien(String maGV) {
        initComponents();
        loadThongTinGiangVien(maGV);
        hienThiThongTinmonhoc(maGV);
        hienThiNamHocCuaGVVaoComboBox(maGV);
        
    }
public String getMaGV() {
    return this.maGV;
}

public void hienThiThongTinmonhoc(String maGV) {
    DefaultTableModel model = (DefaultTableModel) jTable1DiemHocTap.getModel();
    model.setRowCount(0); // Xóa dữ liệu cũ nếu có

    String sql = "SELECT " +

                 "    nhk.NamHoc, " +
                 "    nhk.KiHoc, " +
                 "    lhp.MaLHP, " +  // Thêm cột MaLHP
                 "    mh.TenMon, " +
                 "    mh.SoTinChi, " +
                 "    kh.MaKhoaHoc, " +
                 "    l.TenLop " +
                 "FROM LopHocPhan lhp " +
                 "JOIN MonHoc mh ON lhp.MaMon = mh.MaMon " +
                 "JOIN NamHocKiHoc nhk ON lhp.MaNHKK = nhk.MaNHKK " +
                 "JOIN Lop l ON lhp.MaLop = l.MaLop " +
                 "JOIN KhoaHoc kh ON l.MaKhoaHoc = kh.MaKhoaHoc " +
                 "JOIN GiangVien gv ON lhp.MaGV = gv.MaGV " +
                 "WHERE lhp.MaGV = ?";

    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, maGV); // Gán mã giảng viên vào câu lệnh SQL
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
              // Lấy mã lớp học phần
            String namHoc = rs.getString("NamHoc");
            String kiHoc = rs.getString("KiHoc");
            String maLHP = rs.getString("MaLHP");
            String tenMon = rs.getString("TenMon");
            int soTinChi = rs.getInt("SoTinChi");
            String maKhoaHoc = rs.getString("MaKhoaHoc");
            String tenLop = rs.getString("TenLop");

            model.addRow(new Object[]{ namHoc, kiHoc,maLHP, tenMon, soTinChi, maKhoaHoc, tenLop});
        }

        rs.close();
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Lỗi khi truy vấn dữ liệu!");
    }
}
private void loadThongTinGiangVien(String maGV) {
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
        String sql = "SELECT gv.MaGV, gv.HoTen, gv.NgaySinh, gv.GioiTinh, gv.Email, gv.SDT, gv.DiaChi, gv.NgayVaoLam, " 
                   + "gv.TrinhDo, gv.ChucVu, k.TenKhoa, gv.BoMon, gv.GhiChu, gv.Anh " 
                   + "FROM GiangVien gv " 
                   + "JOIN Khoa k ON gv.MaKhoa = k.MaKhoa " 
                   + "WHERE gv.MaGV = ?";
        pst = conn.prepareStatement(sql);
        pst.setString(1, maGV);
        rs = pst.executeQuery();

        if (rs.next()) {
            // Định dạng ngày trước khi hiển thị
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            // Chuyển đổi ngày sinh
            java.sql.Date ngaySinhSQL = rs.getDate("NgaySinh");
            String ngaySinhFormatted = (ngaySinhSQL != null) ? sdf.format(ngaySinhSQL) : "";

            // Chuyển đổi ngày vào làm
            java.sql.Date ngayVaoLamSQL = rs.getDate("NgayVaoLam");
            String ngayVaoLamFormatted = (ngayVaoLamSQL != null) ? sdf.format(ngayVaoLamSQL) : "";

            jLabel5HienMaSinhVien.setText(rs.getString("MaGV"));
            MAGV.setText(rs.getString("MaGV"));
            TENGV.setText(rs.getString("HoTen"));
            NgaySinh.setText(ngaySinhFormatted); // Hiển thị ngày theo định dạng dd/MM/yyyy
            NgayVaoLam.setText(ngayVaoLamFormatted);

            // Hiển thị thông tin giảng viên lên giao diện
            jLabel4HienTenSinhVien.setText(rs.getString("HoTen"));
            Email.setText(rs.getString("Email"));
            SDT.setText(rs.getString("SDT"));
            GioiTinh.setText(rs.getString("GioiTinh"));
            DiaChi.setText(rs.getString("DiaChi"));
            TrinhDo.setText(rs.getString("TrinhDo"));
            ChucVu.setText(rs.getString("ChucVu"));
            TenKhoa.setText(rs.getString("TenKhoa"));
            BoMon.setText(rs.getString("BoMon"));
            GhiCHu.setText(rs.getString("GhiChu"));

            // Hiển thị ảnh giảng viên lên `JLabel`
            byte[] imgData = rs.getBytes("Anh");
            if (imgData != null) {
                ImageIcon image = new ImageIcon(imgData);
                AnhGV.setIcon(image);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy giảng viên!");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Lỗi tải thông tin: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        AnhGV1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5HienMaSinhVien = new javax.swing.JLabel();
        jLabel4HienTenSinhVien = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        AnhGV = new javax.swing.JLabel();
        jButton2ChonAnh = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        MAGV = new javax.swing.JTextPane();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TENGV = new javax.swing.JTextPane();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        NgaySinh = new javax.swing.JTextPane();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Email = new javax.swing.JTextPane();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        SDT = new javax.swing.JTextPane();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        DiaChi = new javax.swing.JTextPane();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        NgayVaoLam = new javax.swing.JTextPane();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        TrinhDo = new javax.swing.JTextPane();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        ChucVu = new javax.swing.JTextPane();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        TenChuyenNGanh = new javax.swing.JTextPane();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        TenKhoa = new javax.swing.JTextPane();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        BoMon = new javax.swing.JTextPane();
        jButton3Luu = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        TaiKhoan = new javax.swing.JTextPane();
        jScrollPane15 = new javax.swing.JScrollPane();
        NhapLaiMk = new javax.swing.JTextPane();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        MatKhauMoi = new javax.swing.JTextPane();
        jLabel18 = new javax.swing.JLabel();
        jButton4DoiMatKhau = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        GioiTinh = new javax.swing.JTextPane();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        GhiCHu = new javax.swing.JTextPane();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane18 = new javax.swing.JScrollPane();
        jTable1DiemHocTap = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        jComboBox1NamHoc = new javax.swing.JComboBox<>();
        jLabel21 = new javax.swing.JLabel();
        jComboBox2KiHoc = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        HienThi = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        AnhGV1.setText("ẢNh ");

        jLabel2.setText("Họ và Tên: ");

        jLabel3.setText("Mã Giảng Viên: ");

        jLabel5HienMaSinhVien.setText("Hiện mã Giảng viên");

        jLabel4HienTenSinhVien.setText("Hiện tên Giản viên");

        jButton1.setText("Đăng xuất");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        AnhGV.setText("Ảnh Giảng viên");

        jButton2ChonAnh.setText("Chọn ảnh");
        jButton2ChonAnh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ChonAnhActionPerformed(evt);
            }
        });

        jLabel1.setText("Mã Giảng Viên");

        MAGV.setEditable(false);
        jScrollPane1.setViewportView(MAGV);

        jLabel4.setText("Họ và Tên");

        TENGV.setEditable(false);
        jScrollPane2.setViewportView(TENGV);

        jLabel5.setText("Ngày sinh");

        jScrollPane3.setViewportView(NgaySinh);

        jLabel6.setText("Giới tính");

        jLabel7.setText("Email");

        jScrollPane5.setViewportView(Email);

        jLabel8.setText("Số điện thoại");

        jScrollPane6.setViewportView(SDT);

        jLabel9.setText("Địa chỉ");

        jScrollPane7.setViewportView(DiaChi);

        jLabel10.setText("Ngày vào làm");

        jScrollPane8.setViewportView(NgayVaoLam);

        jLabel11.setText("Trình Độ");

        TrinhDo.setEditable(false);
        jScrollPane9.setViewportView(TrinhDo);

        jLabel12.setText("Chức vụ");

        ChucVu.setEditable(false);
        jScrollPane10.setViewportView(ChucVu);

        jLabel13.setText("Căn cước công dân");

        TenChuyenNGanh.setEditable(false);
        jScrollPane11.setViewportView(TenChuyenNGanh);

        jLabel14.setText("Khoa");

        TenKhoa.setEditable(false);
        jScrollPane12.setViewportView(TenKhoa);

        jLabel15.setText("Bộ môn");

        BoMon.setEditable(false);
        jScrollPane13.setViewportView(BoMon);

        jButton3Luu.setText("Lưu");
        jButton3Luu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3LuuActionPerformed(evt);
            }
        });

        jLabel16.setText("Tài khoản");

        jScrollPane14.setViewportView(TaiKhoan);

        jScrollPane15.setViewportView(NhapLaiMk);

        jLabel17.setText("Nhập lại mật khẩu mới");

        jScrollPane16.setViewportView(MatKhauMoi);

        jLabel18.setText("Mật khẩu mới");

        jButton4DoiMatKhau.setText("Đổi mật khẩu");
        jButton4DoiMatKhau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4DoiMatKhauActionPerformed(evt);
            }
        });

        jScrollPane4.setViewportView(GioiTinh);

        jLabel19.setText("Ghi chú");

        jScrollPane17.setViewportView(GhiCHu);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(AnhGV, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jButton3Luu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2ChonAnh, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4DoiMatKhau, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel15)
                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane15)
                    .addComponent(jLabel17)
                    .addComponent(jScrollPane14)
                    .addComponent(jScrollPane12)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane10)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane8)
                    .addComponent(jScrollPane6)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(AnhGV, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2ChonAnh)
                        .addGap(17, 17, 17)
                        .addComponent(jButton3Luu)
                        .addGap(18, 18, 18)
                        .addComponent(jButton4DoiMatKhau))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel8)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel9)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel10)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel11)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel12)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel13)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel14)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel16))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel17)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel18)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(jScrollPane17))))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thông tin Giảng viên", jPanel1);

        jTable1DiemHocTap.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Năm học", "Kì học", "Mã học phần", "Tên môn học", "Số tín chỉ", "Khóa học", "Tên lớp"
            }
        ));
        jScrollPane18.setViewportView(jTable1DiemHocTap);

        jLabel20.setText("Năm học");

        jComboBox1NamHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1NamHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1NamHocActionPerformed(evt);
            }
        });

        jLabel21.setText("Kì học");

        jComboBox2KiHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox2KiHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox2KiHocActionPerformed(evt);
            }
        });

        jButton2.setText("Reset");

        HienThi.setText("Hiển thị");
        HienThi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HienThiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addGap(83, 83, 83)
                        .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jComboBox1NamHoc, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jComboBox2KiHoc, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(HienThi)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1NamHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox2KiHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(HienThi))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 455, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Điểm học tập", jPanel2);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(AnhGV1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4HienTenSinhVien)
                            .addComponent(jLabel5HienMaSinhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTabbedPane1)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2)
                                .addComponent(jLabel4HienTenSinhVien))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(jLabel5HienMaSinhVien)))
                        .addComponent(AnhGV1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private byte[] anhSinhVien; // Biến toàn cục để lưu ảnh dạng byte[]
    private void jButton2ChonAnhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ChonAnhActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Chọn ảnh sinh viên");
    fileChooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png"));

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {
        File selectedFile = fileChooser.getSelectedFile();
        try {
            // Hiển thị ảnh
            ImageIcon icon = new ImageIcon(selectedFile.getAbsolutePath());
            Image img = icon.getImage().getScaledInstance(AnhGV.getWidth(), AnhGV.getHeight(), Image.SCALE_SMOOTH);
            AnhGV.setIcon(new ImageIcon(img)); // Giả sử bạn có JLabel tên là AnhLabel

            // Đọc ảnh thành byte[] để lưu vào DB
            FileInputStream fis = new FileInputStream(selectedFile);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int read;
            while ((read = fis.read(buffer)) != -1) {
                bos.write(buffer, 0, read);
            }
            anhSinhVien = bos.toByteArray();

            fis.close();
            bos.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi đọc file ảnh: " + ex.getMessage());
        }
    }
    }//GEN-LAST:event_jButton2ChonAnhActionPerformed

    private void jButton4DoiMatKhauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4DoiMatKhauActionPerformed
        // TODO add your handling code here:
               // TODO add your handling code here:
        String tenDangNhap = TaiKhoan.getText().trim();
    String matKhauMoi = MatKhauMoi.getText().trim();
    String nhapLaiMatKhau = NhapLaiMk.getText().trim();

    // Kiểm tra rỗng
    if (tenDangNhap.isEmpty() || matKhauMoi.isEmpty() || nhapLaiMatKhau.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin.");
        return;
    }

    // Kiểm tra mật khẩu mới và nhập lại khớp nhau
    if (!matKhauMoi.equals(nhapLaiMatKhau)) {
        JOptionPane.showMessageDialog(this, "Mật khẩu mới không khớp nhau.");
        return;
    }

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();

        // Kiểm tra tài khoản sinh viên tồn tại
        String sqlCheck = "SELECT * FROM TaiKhoan WHERE TenDangNhap = ? AND VaiTro = 'giangvien'";
        pst = conn.prepareStatement(sqlCheck);
        pst.setString(1, tenDangNhap);
        rs = pst.executeQuery();

        if (rs.next()) {
            // Đóng ResultSet & Statement trước khi update
            rs.close();
            pst.close();

            // Cập nhật mật khẩu mới
            String sqlUpdate = "UPDATE TaiKhoan SET MatKhau = ? WHERE TenDangNhap = ?";
            pst = conn.prepareStatement(sqlUpdate);
            pst.setString(1, matKhauMoi);
            pst.setString(2, tenDangNhap);

            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Đổi mật khẩu thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Không thể cập nhật mật khẩu.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Tài khoản sinh viên không tồn tại!");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_jButton4DoiMatKhauActionPerformed

    private void jButton3LuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3LuuActionPerformed
Connection conn = null;
PreparedStatement pst = null;

try {
    conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();

    String sql = "UPDATE GiangVien SET HoTen = ?, NgaySinh = ?, GioiTinh = ?, Email = ?, SDT = ?, DiaChi = ?, " 
               + "NgayVaoLam = ?, TrinhDo = ?, ChucVu = ?, BoMon = ?, GhiChu = ?, Anh = ? WHERE MaGV = ?";

    pst = conn.prepareStatement(sql);

    // Lấy dữ liệu từ giao diện
    pst.setString(1, TENGV.getText().trim());

    // Định dạng ngày: dd/MM/yyyy
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    sdf.setLenient(false); // Bắt lỗi định dạng sai (vd: 31/02/2024)

    java.util.Date ngaySinhUtil, ngayVaoLamUtil;

    try {
        ngaySinhUtil = sdf.parse(NgaySinh.getText().trim());
        ngayVaoLamUtil = sdf.parse(NgayVaoLam.getText().trim());
    } catch (ParseException ex) {
        JOptionPane.showMessageDialog(this, "Ngày không hợp lệ. Vui lòng nhập theo định dạng dd/MM/yyyy!");
        return; // Dừng thực hiện nếu lỗi
    }

    pst.setDate(2, new java.sql.Date(ngaySinhUtil.getTime()));
    pst.setString(3, GioiTinh.getText().trim());
    pst.setString(4, Email.getText().trim());
    pst.setString(5, SDT.getText().trim());
    pst.setString(6, DiaChi.getText().trim());
    pst.setDate(7, new java.sql.Date(ngayVaoLamUtil.getTime()));
    pst.setString(8, TrinhDo.getText().trim());
    pst.setString(9, ChucVu.getText().trim());
    pst.setString(10, BoMon.getText().trim());
    pst.setString(11, GhiCHu.getText().trim());

    // Xử lý ảnh
    byte[] imgData = getAnhTuJLabel(AnhGV);
    if (imgData != null) {
        pst.setBytes(12, imgData);
    } else {
        pst.setNull(12, java.sql.Types.BLOB);
    }

    pst.setString(13, MAGV.getText().trim());

    int rowsAffected = pst.executeUpdate();
    if (rowsAffected > 0) {
        JOptionPane.showMessageDialog(this, "Cập nhật thông tin giảng viên thành công!");
    } else {
        JOptionPane.showMessageDialog(this, "Cập nhật thất bại! Không tìm thấy giảng viên.");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Lỗi cập nhật thông tin: " + e.getMessage());
} finally {
    try {
        if (pst != null) pst.close();
        if (conn != null) conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    }//GEN-LAST:event_jButton3LuuActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
           // TODO add your handling code here:
        int choice = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất?", "Xác nhận", JOptionPane.YES_NO_OPTION);
    
    if (choice == JOptionPane.YES_OPTION) {
        // Mở lại giao diện đăng nhập
        new DangNhap().setVisible(true);

        // Đóng giao diện hiện tại
        this.dispose(); // hoặc setVisible(false);
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jComboBox1NamHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1NamHocActionPerformed
        String namHocDuocChon = (String) jComboBox1NamHoc.getSelectedItem();
        String maGV = jLabel5HienMaSinhVien.getText().trim(); // Lấy mã giảng viên từ jLabel

        if (namHocDuocChon.equals("-- Chọn năm học --")) {
            // Không hiển thị thông báo lỗi, chỉ reset bảng
            hienThiThongTinmonhoc(maGV); 
            jComboBox2KiHoc.setModel(new DefaultComboBoxModel<>(new String[]{"-- Chọn kỳ học --"})); // Reset kỳ học
        } else {
            // Nếu chọn năm hợp lệ, hiển thị danh sách môn học
            hienThiMonHocTheoNam(maGV, namHocDuocChon);
            // Cập nhật danh sách kỳ học của năm học vừa chọn
            hienThiKiHocTheoNam(namHocDuocChon);
}
    }//GEN-LAST:event_jComboBox1NamHocActionPerformed

    private void jComboBox2KiHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox2KiHocActionPerformed
        // TODO add your handling code here:
        String namHoc = (String) jComboBox1NamHoc.getSelectedItem(); // Năm học đã chọn
        String kiHoc = (String) jComboBox2KiHoc.getSelectedItem();  // Kỳ học đã chọn
        String maGV = jLabel5HienMaSinhVien.getText().trim(); // Lấy mã giảng viên từ jLabel

        if (kiHoc.equals("-- Chọn kỳ học --")) {
            hienThiMonHocTheoNam(maGV, namHoc); // Hiển thị môn theo năm nếu chưa chọn kỳ
        } else {
            hienThiMonHocTheoNamVaKiHoc(maGV, namHoc, kiHoc); // Hiển thị môn theo năm + kỳ
        
        }

    }//GEN-LAST:event_jComboBox2KiHocActionPerformed

    private void HienThiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HienThiActionPerformed
// TODO add your handling code here:
int row = jTable1DiemHocTap.getSelectedRow(); // Lấy dòng được chọn

if (row != -1) {
    String maLHP = (String) jTable1DiemHocTap.getValueAt(row, 2); // Mã lớp học phần
    String tenMon = (String) jTable1DiemHocTap.getValueAt(row, 3); // Tên môn học
    String maLop = (String) jTable1DiemHocTap.getValueAt(row, 6);  // Mã lớp học

    // Kiểm tra nếu dữ liệu không bị null hoặc rỗng
    if (!maLHP.isEmpty() && !tenMon.isEmpty() && !maLop.isEmpty()) {
        // Mở form NhapDiem.java mà không đóng form hiện tại
        NhapDiem nhapDiemForm = new NhapDiem();
        
        // Truyền dữ liệu vào form NhapDiem.java thông qua setter
        nhapDiemForm.setThongTinMonHoc(maLHP, tenMon, maLop);
        
        // Hiển thị form NhapDiem
        nhapDiemForm.setVisible(true);
        // Lưu ý: Không gọi dispose() hay setVisible(false) trên form hiện tại,
        // để form này vẫn giữ nguyên và không bị đóng khi mở form NhapDiem.
    } else {
        JOptionPane.showMessageDialog(null, "❌ Vui lòng chọn một dòng hợp lệ!");
    }
} else {
    JOptionPane.showMessageDialog(null, "❌ Bạn chưa chọn dòng nào trên bảng!");
}
    }//GEN-LAST:event_HienThiActionPerformed

    
    public void hienThiMonHocTheoNamVaKiHoc(String maGV, String namHoc, String kiHoc) {
    DefaultTableModel model = (DefaultTableModel) jTable1DiemHocTap.getModel();
    model.setRowCount(0); // Xóa dữ liệu cũ trước khi hiển thị mới

    String sql = "SELECT nhk.NamHoc, nhk.KiHoc, lhp.MaLHP, mh.TenMon, mh.SoTinChi, kh.MaKhoaHoc, l.TenLop " +
                 "FROM LopHocPhan lhp " +
                 "JOIN MonHoc mh ON lhp.MaMon = mh.MaMon " +
                 "JOIN NamHocKiHoc nhk ON lhp.MaNHKK = nhk.MaNHKK " +
                 "JOIN Lop l ON lhp.MaLop = l.MaLop " +
                 "JOIN KhoaHoc kh ON l.MaKhoaHoc = kh.MaKhoaHoc " +
                 "WHERE nhk.NamHoc = ? AND nhk.KiHoc = ? AND lhp.MaGV = ? " +
                 "ORDER BY nhk.KiHoc ASC";

    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, namHoc);
        pstmt.setString(2, kiHoc);
        pstmt.setString(3, maGV);

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("NamHoc"),
                rs.getString("KiHoc"),
                rs.getString("MaLHP"),  // Thêm Mã lớp học phần
                rs.getString("TenMon"),
                rs.getInt("SoTinChi"),
                rs.getString("MaKhoaHoc"),
                rs.getString("TenLop")
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Lỗi khi tải dữ liệu môn học!");
    }
}
public void hienThiKiHocTheoNam(String namHoc) {
    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
    jComboBox2KiHoc.setModel(model);
    model.addElement("-- Chọn kỳ học --");

    String sql = "SELECT DISTINCT KiHoc FROM NamHocKiHoc WHERE NamHoc = ? ORDER BY KiHoc ASC";

    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, namHoc);
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            model.addElement(rs.getString("KiHoc"));
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Lỗi khi tải danh sách kỳ học!");
    }
}
    public void hienThiMonHocTheoNam(String maGV, String namHoc) {
    DefaultTableModel model = (DefaultTableModel) jTable1DiemHocTap.getModel();
    model.setRowCount(0); // Xóa dữ liệu cũ trước khi hiển thị mới

    String sql = "SELECT nhk.NamHoc, nhk.KiHoc, lhp.MaLHP, mh.TenMon, mh.SoTinChi, kh.MaKhoaHoc, l.TenLop " +
                 "FROM LopHocPhan lhp " +
                 "JOIN MonHoc mh ON lhp.MaMon = mh.MaMon " +
                 "JOIN NamHocKiHoc nhk ON lhp.MaNHKK = nhk.MaNHKK " +
                 "JOIN Lop l ON lhp.MaLop = l.MaLop " +
                 "JOIN KhoaHoc kh ON l.MaKhoaHoc = kh.MaKhoaHoc " +
                 "WHERE nhk.NamHoc = ? AND lhp.MaGV = ? " +
                 "ORDER BY nhk.KiHoc ASC";

    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, namHoc);
        pstmt.setString(2, maGV);

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("NamHoc"),
                rs.getString("KiHoc"),
                rs.getString("MaLHP"),  // Thêm mã lớp học phần
                rs.getString("TenMon"),
                rs.getInt("SoTinChi"),
                rs.getString("MaKhoaHoc"),
                rs.getString("TenLop")
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Lỗi khi tải dữ liệu môn học!");
    }
}
    private byte[] getAnhTuJLabel(JLabel label) {
    Icon icon = label.getIcon();
    if (icon instanceof ImageIcon) {
        Image image = ((ImageIcon) icon).getImage();
        BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
        Graphics g = bufferedImage.createGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();
        
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(bufferedImage, "jpg", baos);
            return baos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    return null;
}
public void hienThiNamHocCuaGVVaoComboBox(String maGV) {
    if (maGV == null || maGV.trim().isEmpty()) {
        JOptionPane.showMessageDialog(null, "❌ Mã giảng viên không hợp lệ!");
        return;
    }

    DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
    jComboBox1NamHoc.setModel(model);
    model.addElement("-- Chọn năm học --");

    String sql = "SELECT DISTINCT nhk.NamHoc " +
                 "FROM LopHocPhan lhp " +
                 "JOIN NamHocKiHoc nhk ON lhp.MaNHKK = nhk.MaNHKK " +
                 "WHERE lhp.MaGV = ? " +
                 "ORDER BY nhk.NamHoc DESC";

    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, maGV);
        try (ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                model.addElement(rs.getString("NamHoc"));
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Lỗi khi tải danh sách năm học từ CSDL!");
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AnhGV;
    private javax.swing.JLabel AnhGV1;
    private javax.swing.JTextPane BoMon;
    private javax.swing.JTextPane ChucVu;
    private javax.swing.JTextPane DiaChi;
    private javax.swing.JTextPane Email;
    private javax.swing.JTextPane GhiCHu;
    private javax.swing.JTextPane GioiTinh;
    private javax.swing.JButton HienThi;
    private javax.swing.JTextPane MAGV;
    private javax.swing.JTextPane MatKhauMoi;
    private javax.swing.JTextPane NgaySinh;
    private javax.swing.JTextPane NgayVaoLam;
    private javax.swing.JTextPane NhapLaiMk;
    private javax.swing.JTextPane SDT;
    private javax.swing.JTextPane TENGV;
    private javax.swing.JTextPane TaiKhoan;
    private javax.swing.JTextPane TenChuyenNGanh;
    private javax.swing.JTextPane TenKhoa;
    private javax.swing.JTextPane TrinhDo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton2ChonAnh;
    private javax.swing.JButton jButton3Luu;
    private javax.swing.JButton jButton4DoiMatKhau;
    private javax.swing.JComboBox<String> jComboBox1NamHoc;
    private javax.swing.JComboBox<String> jComboBox2KiHoc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel4HienTenSinhVien;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel5HienMaSinhVien;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1DiemHocTap;
    // End of variables declaration//GEN-END:variables
}
