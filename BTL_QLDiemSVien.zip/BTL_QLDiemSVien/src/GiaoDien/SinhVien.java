/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GiaoDien;
import Style.GiaoDienMacDinh;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Xử lý file ảnh
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

// Xử lý CSDL
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// Xử lý ngày tháng
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;



/**
 *
 * @author ky
 */
public class SinhVien extends javax.swing.JFrame {
private String maSV; // lưu mã sinh viên đã đăng nhập
    /**
     * Creates new form SinhVien
     */
    public SinhVien() {
        initComponents();
        String maSV = null;
        loadSinhVien(maSV);
        loadBangDiem(maSV);
        HienThi();
        GiaoDienMacDinh.caiDatFlatLaf();
        icon();
        tuyChinhGiaoDien();
    }
    public SinhVien(String maSV) {
        initComponents();
        loadSinhVien(maSV); // Hàm load dữ liệu sinh viên theo mã
                loadBangDiem(maSV);
                HienThi();
                loadDataToTableChuongTrinhDaoTaoSinhVien(maSV);
    }
private void loadDataToTableChuongTrinhDaoTaoSinhVien(String maSV) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "SELECT NH.NamHoc, NH.KiHoc, MH.MaMon, MH.TenMon, MH.SoTinChi, CTDT.BatBuoc " +
                     "FROM SinhVien SV " +
                     "JOIN Lop L ON SV.MaLop = L.MaLop " +
                     "JOIN LopHocPhan LHP ON L.MaLop = LHP.MaLop " +
                     "JOIN MonHoc MH ON LHP.MaMon = MH.MaMon " +
                     "JOIN NamHocKiHoc NH ON LHP.MaNHKK = NH.MaNHKK " +
                     "JOIN ChuongTrinhDaoTao CTDT ON MH.MaMon = CTDT.MaMon " +
                     "WHERE SV.MaSV = ?";
        
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, maSV);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            Object[] row = {
                rs.getString("NamHoc"),
                rs.getString("KiHoc"),
                rs.getString("MaMon"),
                rs.getString("TenMon"),
                rs.getInt("SoTinChi"),
                rs.getBoolean("BatBuoc") ? "✔ Bắt buộc" : "✘ Không bắt buộc"
            };
            model.addRow(row);
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải chương trình đào tạo: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
     // Hàm load dữ liệu từ CSDL lên form dựa vào mã SV
    private void loadSinhVien(String maSV) {
    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();

        String sql = "SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, sv.Email, sv.SDT, sv.DiaChi, "
                   + "sv.NgayVaoHoc, sv.TrangThai, sv.CCCD, sv.GhiChu, sv.Anh, "
                   + "l.TenLop, cn.TenCN, k.TenKhoa "
                   + "FROM SinhVien sv "
                   + "JOIN Lop l ON sv.MaLop = l.MaLop "
                   + "JOIN ChuyenNganh cn ON l.MaCN = cn.MaCN "
                   + "JOIN Khoa k ON cn.MaKhoa = k.MaKhoa "
                   + "WHERE sv.MaSV = ?";

        pst = conn.prepareStatement(sql);
        pst.setString(1, maSV);
        rs = pst.executeQuery();

        if (rs.next()) {
            // Set text fields
            jLabel5HienMaSinhVien.setText(rs.getString("MaSV"));
            jLabel4HienTenSinhVien.setText(rs.getString("HoTen"));
            
            MaSV.setText(rs.getString("MaSV"));
            TenSV.setText(rs.getString("HoTen"));

            java.sql.Date ngaySinhSQL = rs.getDate("NgaySinh");
            java.sql.Date ngayVaoHocSQL = rs.getDate("NgayVaoHoc");
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

            NgaySinh.setText(ngaySinhSQL != null ? sdf.format(ngaySinhSQL) : "");
            NgayNhapHoc.setText(ngayVaoHocSQL != null ? sdf.format(ngayVaoHocSQL) : "");

            GioiTinh.setText(rs.getString("GioiTinh"));
            Email.setText(rs.getString("Email"));
            SDT.setText(rs.getString("SDT"));
            DiaChi.setText(rs.getString("DiaChi"));
            TrangThai.setText(rs.getString("TrangThai"));
            CCCD.setText(rs.getString("CCCD"));
            jTextField1GhiChu.setText(rs.getString("GhiChu"));

            TenLop.setText(rs.getString("TenLop"));
            TenChuyenNGanh.setText(rs.getString("TenCN"));
            TenKhoa.setText(rs.getString("TenKhoa"));

            // Hiển thị ảnh lên cả hai JLabel
            byte[] imageBytes = rs.getBytes("Anh");
            if (imageBytes != null && imageBytes.length > 0) {
                this.anhSinhVien = imageBytes; // lưu nếu cần sửa

                ImageIcon icon = new ImageIcon(imageBytes);
                Image scaledImage1 = icon.getImage().getScaledInstance(jLabel6HienAnhSinhVien.getWidth(), jLabel6HienAnhSinhVien.getHeight(), Image.SCALE_SMOOTH);
                jLabel6HienAnhSinhVien.setIcon(new ImageIcon(scaledImage1));

                Image scaledImage2 = icon.getImage().getScaledInstance(jLabel1HienAnhSinhVien.getWidth(), jLabel1HienAnhSinhVien.getHeight(), Image.SCALE_SMOOTH);
                jLabel1HienAnhSinhVien.setIcon(new ImageIcon(scaledImage2));
            } else {
                jLabel6HienAnhSinhVien.setIcon(null);
                jLabel1HienAnhSinhVien.setIcon(null);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin sinh viên!");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Lỗi truy vấn dữ liệu: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
public void loadBangDiem(String maSV) {
        DefaultTableModel model = (DefaultTableModel) jTable1Diem.getModel();
        model.setRowCount(0);

        String url = "jdbc:mysql://localhost:3306/quanlydiem";
        String user = "root";
        String password = "822004";

        String sql = "SELECT nhk.NamHoc, nhk.KiHoc, mh.MaMon, mh.TenMon, mh.SoTinChi, " +
                     "d.DiemCC, d.DiemGK, d.DiemCK, d.DiemTongKet, d.GhiChu " +
                     "FROM Diem d " +
                     "JOIN LopHocPhan lhp ON d.MaLHP = lhp.MaLHP " +
                     "JOIN MonHoc mh ON lhp.MaMon = mh.MaMon " +
                     "JOIN NamHocKiHoc nhk ON lhp.MaNHKK = nhk.MaNHKK " +
                     "WHERE d.MaSV = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setString(1, maSV);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                float diemTongKet = rs.getFloat("DiemTongKet");
                float diemThang4 = convertToThang4(diemTongKet);
                String diemChu = convertToChu(diemTongKet);

                Object[] row = {
                    rs.getInt("NamHoc"),
                    rs.getInt("KiHoc"),
                    rs.getString("MaMon"),
                    rs.getString("TenMon"),
                    rs.getInt("SoTinChi"),
                    rs.getFloat("DiemCC"),
                    rs.getFloat("DiemGK"),
                    rs.getFloat("DiemCK"),
                    diemTongKet,
                    diemThang4,
                    diemChu,
                    rs.getString("GhiChu")
                };

                model.addRow(row);
            }

            rs.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi load bảng điểm: " + e.getMessage());
        }
    }
private void HienThi() {
    TableModel model = jTable1Diem.getModel();

    float tongDiemThang10 = 0f;
    float tongDiemNhanTC_Thang4 = 0f;
    int tongTinChi = 0;
    int tongTinChiTichLuy = 0;
    int soMon = 0;
    int soMonHocLai = 0;

    for (int i = 0; i < model.getRowCount(); i++) {
        try {
            float diemThang10 = Float.parseFloat(model.getValueAt(i, 8).toString()); // Thang điểm 10
            int tinChi = Integer.parseInt(model.getValueAt(i, 4).toString());        // Số tín chỉ

            // Tính trung bình cộng đơn giản
            tongDiemThang10 += diemThang10;
            soMon++;

            // Quy đổi sang thang 4 và cộng có trọng số
            float diemThang4 = convertToThang4(diemThang10);
            tongDiemNhanTC_Thang4 += diemThang4 * tinChi;
            tongTinChi += tinChi;

            // Tín chỉ tích lũy và học lại
            if (diemThang10 >= 4.0f) {
                tongTinChiTichLuy += tinChi;
                model.setValueAt("", i, 11); // Ghi chú: ""
            } else {
                soMonHocLai++;
                model.setValueAt("Học lại", i, 11); // Ghi chú: Học lại
            }

            // Cập nhật thang điểm 4 và chữ luôn (nếu cần)
            model.setValueAt(String.format("%.2f", diemThang4), i, 9);  // Thang điểm 4
            model.setValueAt(convertToChu(diemThang10), i, 10);         // Thang điểm chữ

        } catch (Exception e) {
            // Bỏ qua dòng nếu dữ liệu lỗi
        }
    }

    // Trung bình cộng thang 10 (không trọng số)
    if (soMon > 0) {
        float diemTB10 = tongDiemThang10 / soMon;
        TBCthangdiem10.setText(String.format("%.2f", diemTB10));
        xeploaihoclucthang10.setText(xeploaihoclucThang10(diemTB10));
    }

    // Trung bình cộng thang 4 (trọng số tín chỉ)
    if (tongTinChi > 0) {
        float diemTB4 = tongDiemNhanTC_Thang4 / tongTinChi;
        TBCThangDiem4.setText(String.format("%.2f", diemTB4));
        Xeploaihoclucthang4.setText(xeploaihoclucThang4(diemTB4));
    }

    // Cập nhật các thông tin còn lại
    sotinchitichluy.setText(String.valueOf(tongTinChiTichLuy));
    jTextPane3.setText(String.valueOf(soMonHocLai));
}


public float convertToThang4(float diem10) {
    if (diem10 >= 8.5f) return 4.0f;
    if (diem10 >= 7.0f) return 3.0f;
    if (diem10 >= 5.5f) return 2.0f;
    if (diem10 >= 4.0f) return 1.0f;
    return 0.0f;
}

public String convertToChu(float diem10) {
    if (diem10 >= 8.5f) return "A";
    if (diem10 >= 7.0f) return "B";
    if (diem10 >= 5.5f) return "C";
    if (diem10 >= 4.0f) return "D";
    return "F";
}

private String xeploaihoclucThang4(float diemTB4) {
    if (diemTB4 >= 3.6f) return "Giỏi";
    if (diemTB4 >= 3.2f) return "Khá";
    if (diemTB4 >= 2.5f) return "Trung bình khá";
    if (diemTB4 >= 2.0f) return "Trung bình";
    return "Yếu";
}

private String xeploaihoclucThang10(float diemTB10) {
    if (diemTB10 >= 8.5f) return "Giỏi";
    if (diemTB10 >= 7.0f) return "Khá";
    if (diemTB10 >= 5.5f) return "Trung bình";
    if (diemTB10 >= 4.0f) return "Yếu";
    return "Kém";
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        DangXuat = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel6HienAnhSinhVien = new javax.swing.JLabel();
        jButton2ChonAnh = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        MaSV = new javax.swing.JTextPane();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TenSV = new javax.swing.JTextPane();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        NgaySinh = new javax.swing.JTextPane();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        Email = new javax.swing.JTextPane();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        SDT = new javax.swing.JTextPane();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        DiaChi = new javax.swing.JTextPane();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        NgayNhapHoc = new javax.swing.JTextPane();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        TrangThai = new javax.swing.JTextPane();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        TenLop = new javax.swing.JTextPane();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        TenChuyenNGanh = new javax.swing.JTextPane();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        TenKhoa = new javax.swing.JTextPane();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        CCCD = new javax.swing.JTextPane();
        jButton3Luu = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        NhapTaiKhoan = new javax.swing.JTextPane();
        jScrollPane15 = new javax.swing.JScrollPane();
        NhapLaiMkMoi = new javax.swing.JTextPane();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        MatKhaumoi = new javax.swing.JTextPane();
        jLabel18 = new javax.swing.JLabel();
        jButton4DoiMatKhau = new javax.swing.JButton();
        jScrollPane17 = new javax.swing.JScrollPane();
        GioiTinh = new javax.swing.JTextPane();
        jLabel19 = new javax.swing.JLabel();
        jTextField1GhiChu = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1Diem = new javax.swing.JTable();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane18 = new javax.swing.JScrollPane();
        TBCThangDiem4 = new javax.swing.JTextPane();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        Xeploaihoclucthang4 = new javax.swing.JTextPane();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        TBCthangdiem10 = new javax.swing.JTextPane();
        jScrollPane21 = new javax.swing.JScrollPane();
        xeploaihoclucthang10 = new javax.swing.JTextPane();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        Monhoclaij = new javax.swing.JScrollPane();
        jTextPane3 = new javax.swing.JTextPane();
        jLabel25 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        sotinchitichluy = new javax.swing.JTextPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane22 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1HienAnhSinhVien = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4HienTenSinhVien = new javax.swing.JLabel();
        jLabel5HienMaSinhVien = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        DangXuat.setText("Đăng xuất");
        DangXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DangXuatActionPerformed(evt);
            }
        });

        jLabel6HienAnhSinhVien.setText("Ảnh sinh viên");

        jButton2ChonAnh.setText("Chọn ảnh");
        jButton2ChonAnh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ChonAnhActionPerformed(evt);
            }
        });

        jLabel1.setText("Mã Sinh viên");

        MaSV.setEditable(false);
        jScrollPane1.setViewportView(MaSV);

        jLabel4.setText("Họ và Tên");

        TenSV.setEditable(false);
        jScrollPane2.setViewportView(TenSV);

        jLabel5.setText("Ngày sinh");

        jScrollPane3.setViewportView(NgaySinh);

        jLabel6.setText("Giới tính");

        jLabel7.setText("Email");

        jScrollPane5.setViewportView(Email);

        jLabel8.setText("Số điện thoại");

        jScrollPane6.setViewportView(SDT);

        jLabel9.setText("Địa chỉ");

        jScrollPane7.setViewportView(DiaChi);

        jLabel10.setText("Ngày nhập học");

        NgayNhapHoc.setEditable(false);
        jScrollPane8.setViewportView(NgayNhapHoc);

        jLabel11.setText("Trạng thái");

        TrangThai.setEditable(false);
        jScrollPane9.setViewportView(TrangThai);

        jLabel12.setText("Tên Lớp");

        TenLop.setEditable(false);
        jScrollPane10.setViewportView(TenLop);

        jLabel13.setText("Tên chuyên ngành");

        TenChuyenNGanh.setEditable(false);
        jScrollPane11.setViewportView(TenChuyenNGanh);

        jLabel14.setText("Tên khoa");

        TenKhoa.setEditable(false);
        jScrollPane12.setViewportView(TenKhoa);

        jLabel15.setText("Căn cước công dân");

        CCCD.setEditable(false);
        jScrollPane13.setViewportView(CCCD);

        jButton3Luu.setText("Lưu");
        jButton3Luu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3LuuActionPerformed(evt);
            }
        });

        jLabel16.setText("Tài khoản");

        jScrollPane14.setViewportView(NhapTaiKhoan);

        jScrollPane15.setViewportView(NhapLaiMkMoi);

        jLabel17.setText("Nhập lại mật khẩu mới");

        jScrollPane16.setViewportView(MatKhaumoi);

        jLabel18.setText("Mật khẩu mới");

        jButton4DoiMatKhau.setText("Đổi mật khẩu");
        jButton4DoiMatKhau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4DoiMatKhauActionPerformed(evt);
            }
        });

        jScrollPane17.setViewportView(GioiTinh);

        jLabel19.setText("Ghi chú");

        jTextField1GhiChu.setText("Ghi chú");
        jTextField1GhiChu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1GhiChuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6HienAnhSinhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jButton3Luu, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton2ChonAnh, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jButton4DoiMatKhau, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel15)
                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addGap(38, 38, 38)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane15, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jLabel17)
                    .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jScrollPane12, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane10, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 161, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel16)
                    .addComponent(jScrollPane17))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(77, 77, 77))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jTextField1GhiChu, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6HienAnhSinhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2ChonAnh)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 63, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel10)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel18)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(52, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)
                            .addComponent(jLabel19))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jButton3Luu)
                                        .addGroup(jPanel1Layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(18, 18, 18)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel7)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                .addGroup(jPanel1Layout.createSequentialGroup()
                                                    .addComponent(jLabel8)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton4DoiMatKhau))
                            .addComponent(jTextField1GhiChu, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())))
        );

        jTabbedPane1.addTab("Thông tin sinh viên", jPanel1);

        jTable1Diem.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Năm học", "Học kì", "Mã môn học", "Tên môn học", "Số tín chỉ", "Điểm chuyên  cần", "Điểm giữa kì", "Điểm cuối kì", "Thang điểm 10", "Thang điểm 4", "Thang điểm chữ", "Ghi chú"
            }
        ));
        jScrollPane4.setViewportView(jTable1Diem);

        jLabel20.setText("TBC Thang điêm 4: ");

        jScrollPane18.setViewportView(TBCThangDiem4);

        jLabel21.setText("Xếp loại học lực thang điểm 4: ");

        jScrollPane19.setViewportView(Xeploaihoclucthang4);

        jLabel22.setText("TBC Thang điêm 10: ");

        jScrollPane20.setViewportView(TBCthangdiem10);

        jScrollPane21.setViewportView(xeploaihoclucthang10);

        jLabel23.setText("Xếp loại học lực thang điểm 10: ");

        jLabel24.setText("Môn học lại:");

        Monhoclaij.setViewportView(jTextPane3);

        jLabel25.setText("Tín chỉ tích lũy");

        jScrollPane23.setViewportView(sotinchitichluy);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(Monhoclaij, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel20, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane18, javax.swing.GroupLayout.Alignment.LEADING))
                            .addComponent(jLabel24))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel25)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jScrollPane23, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel21, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane19, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane20))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane21))))
                        .addGap(0, 36, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel21))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel23))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel24)
                    .addComponent(jLabel25))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Monhoclaij, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Điểm học tập", jPanel2);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Năm học", "Học kì", "Mã Môn", "Tên Môn", "Số tin chỉ", "bắt buộc"
            }
        ));
        jScrollPane22.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 637, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 527, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Chương trình đào tạo", jPanel3);

        jLabel1HienAnhSinhVien.setText("Hiện ảnh sinh viên");

        jLabel2.setText("Họ và Tên: ");

        jLabel3.setText("Mã Sinh Viên: ");

        jLabel4HienTenSinhVien.setText("Hiện tên sinh viên");

        jLabel5HienMaSinhVien.setText("Hiện mã sinh viên");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1HienAnhSinhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4HienTenSinhVien)
                            .addComponent(jLabel5HienMaSinhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(DangXuat))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTabbedPane1)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DangXuat)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel2)
                                .addComponent(jLabel4HienTenSinhVien))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel3)
                                .addComponent(jLabel5HienMaSinhVien)))
                        .addComponent(jLabel1HienAnhSinhVien, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1GhiChuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1GhiChuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1GhiChuActionPerformed
private byte[] anhSinhVien; // Biến toàn cục để lưu ảnh dạng byte[]
    private void jButton2ChonAnhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ChonAnhActionPerformed
        // TODO add your handling code here:
        JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Chọn ảnh sinh viên");
    fileChooser.setFileFilter(new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png"));

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {
        File selectedFile = fileChooser.getSelectedFile();
        try {
            // Hiển thị ảnh
            ImageIcon icon = new ImageIcon(selectedFile.getAbsolutePath());
            Image img = icon.getImage().getScaledInstance(jLabel6HienAnhSinhVien.getWidth(), jLabel6HienAnhSinhVien.getHeight(), Image.SCALE_SMOOTH);
            jLabel6HienAnhSinhVien.setIcon(new ImageIcon(img)); // Giả sử bạn có JLabel tên là AnhLabel

            // Đọc ảnh thành byte[] để lưu vào DB
            FileInputStream fis = new FileInputStream(selectedFile);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int read;
            while ((read = fis.read(buffer)) != -1) {
                bos.write(buffer, 0, read);
            }
            anhSinhVien = bos.toByteArray();

            fis.close();
            bos.close();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Lỗi đọc file ảnh: " + ex.getMessage());
        }
    }
    }//GEN-LAST:event_jButton2ChonAnhActionPerformed

    private void jButton3LuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3LuuActionPerformed
        // TODO add your handling code here:
        Connection conn = null;
    PreparedStatement pst = null;

    try {
        conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();

        String sql = "UPDATE SinhVien SET HoTen = ?, NgaySinh = ?, GioiTinh = ?, Email = ?, SDT = ?, DiaChi = ?, "
                   + "NgayVaoHoc = ?, TrangThai = ?, CCCD = ?, GhiChu = ?, Anh = ? WHERE MaSV = ?";

        pst = conn.prepareStatement(sql);

        pst.setString(1, TenSV.getText().trim());

        // Chuyển đổi ngày từ chuỗi sang java.sql.Date
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        java.util.Date ngaySinhUtil = sdf.parse(NgaySinh.getText().trim());
        java.util.Date ngayVaoHocUtil = sdf.parse(NgayNhapHoc.getText().trim());

        pst.setDate(2, new java.sql.Date(ngaySinhUtil.getTime()));
        pst.setString(3, GioiTinh.getText().trim());
        pst.setString(4, Email.getText().trim());
        pst.setString(5, SDT.getText().trim());
        pst.setString(6, DiaChi.getText().trim());
        pst.setDate(7, new java.sql.Date(ngayVaoHocUtil.getTime()));
        pst.setString(8, TrangThai.getText().trim());
        pst.setString(9, CCCD.getText().trim());
        pst.setString(10, jTextField1GhiChu.getText().trim());

        // Nếu có ảnh mới thì set ảnh, không thì set null
        if (anhSinhVien != null) {
            pst.setBytes(11, anhSinhVien);
        } else {
            pst.setNull(11, java.sql.Types.BLOB);
        }

        pst.setString(12, MaSV.getText().trim()); // WHERE MaSV = ?

        int rows = pst.executeUpdate();
        if (rows > 0) {
            JOptionPane.showMessageDialog(this, "Cập nhật thông tin thành công!");
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên để cập nhật!");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Lỗi cập nhật: " + e.getMessage());
    } finally {
        try {
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // TODO add your handling code here:

try {
    conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();

    // Chỉ cập nhật các trường yêu cầu
    String sql = "UPDATE SinhVien SET NgaySinh = ?, GioiTinh = ?, Email = ?, SDT = ?, DiaChi = ?, GhiChu = ? WHERE MaSV = ?";

    pst = conn.prepareStatement(sql);

    // Chuyển đổi ngày sinh từ chuỗi sang java.sql.Date
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
    java.util.Date ngaySinhUtil = sdf.parse(NgaySinh.getText().trim());

    pst.setDate(1, new java.sql.Date(ngaySinhUtil.getTime())); // NgaySinh
    pst.setString(2, GioiTinh.getText().trim());                // GioiTinh
    pst.setString(3, Email.getText().trim());                   // Email
    pst.setString(4, SDT.getText().trim());                     // SDT
    pst.setString(5, DiaChi.getText().trim());                  // DiaChi
    pst.setString(6, jTextField1GhiChu.getText().trim());       // GhiChu
    pst.setString(7, MaSV.getText().trim());                    // WHERE MaSV = ?

    int rows = pst.executeUpdate();
    if (rows > 0) {
        JOptionPane.showMessageDialog(this, "Cập nhật thông tin thành công!");
    } else {
        JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên để cập nhật!");
    }

} catch (Exception e) {
    JOptionPane.showMessageDialog(this, "Lỗi cập nhật: " + e.getMessage());
} finally {
    try {
        if (pst != null) pst.close();
        if (conn != null) conn.close();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

    }//GEN-LAST:event_jButton3LuuActionPerformed

    private void jButton4DoiMatKhauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4DoiMatKhauActionPerformed
        // TODO add your handling code here:
        String tenDangNhap = NhapTaiKhoan.getText().trim();
    String matKhauMoi = MatKhaumoi.getText().trim();
    String nhapLaiMatKhau = NhapLaiMkMoi.getText().trim();

    // Kiểm tra rỗng
    if (tenDangNhap.isEmpty() || matKhauMoi.isEmpty() || nhapLaiMatKhau.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin.");
        return;
    }

    // Kiểm tra mật khẩu mới và nhập lại khớp nhau
    if (!matKhauMoi.equals(nhapLaiMatKhau)) {
        JOptionPane.showMessageDialog(this, "Mật khẩu mới không khớp nhau.");
        return;
    }

    Connection conn = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    try {
        conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();

        // Kiểm tra tài khoản sinh viên tồn tại
        String sqlCheck = "SELECT * FROM TaiKhoan WHERE TenDangNhap = ? AND VaiTro = 'sinhvien'";
        pst = conn.prepareStatement(sqlCheck);
        pst.setString(1, tenDangNhap);
        rs = pst.executeQuery();

        if (rs.next()) {
            // Đóng ResultSet & Statement trước khi update
            rs.close();
            pst.close();

            // Cập nhật mật khẩu mới
            String sqlUpdate = "UPDATE TaiKhoan SET MatKhau = ? WHERE TenDangNhap = ?";
            pst = conn.prepareStatement(sqlUpdate);
            pst.setString(1, matKhauMoi);
            pst.setString(2, tenDangNhap);

            int rows = pst.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "Đổi mật khẩu thành công!");
            } else {
                JOptionPane.showMessageDialog(this, "Không thể cập nhật mật khẩu.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Tài khoản sinh viên không tồn tại!");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
    } finally {
        try {
            if (rs != null) rs.close();
            if (pst != null) pst.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    }//GEN-LAST:event_jButton4DoiMatKhauActionPerformed

    private void DangXuatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DangXuatActionPerformed
        // TODO add your handling code here:
        int choice = JOptionPane.showConfirmDialog(this, "Bạn có chắc chắn muốn đăng xuất?", "Xác nhận", JOptionPane.YES_NO_OPTION);
    
    if (choice == JOptionPane.YES_OPTION) {
        // Mở lại giao diện đăng nhập
        new DangNhap().setVisible(true);

        // Đóng giao diện hiện tại
        this.dispose(); // hoặc setVisible(false);
    }
    }//GEN-LAST:event_DangXuatActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SinhVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SinhVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SinhVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SinhVien.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SinhVien().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextPane CCCD;
    private javax.swing.JButton DangXuat;
    private javax.swing.JTextPane DiaChi;
    private javax.swing.JTextPane Email;
    private javax.swing.JTextPane GioiTinh;
    private javax.swing.JTextPane MaSV;
    private javax.swing.JTextPane MatKhaumoi;
    private javax.swing.JScrollPane Monhoclaij;
    private javax.swing.JTextPane NgayNhapHoc;
    private javax.swing.JTextPane NgaySinh;
    private javax.swing.JTextPane NhapLaiMkMoi;
    private javax.swing.JTextPane NhapTaiKhoan;
    private javax.swing.JTextPane SDT;
    private javax.swing.JTextPane TBCThangDiem4;
    private javax.swing.JTextPane TBCthangdiem10;
    private javax.swing.JTextPane TenChuyenNGanh;
    private javax.swing.JTextPane TenKhoa;
    private javax.swing.JTextPane TenLop;
    private javax.swing.JTextPane TenSV;
    private javax.swing.JTextPane TrangThai;
    private javax.swing.JTextPane Xeploaihoclucthang4;
    private javax.swing.JButton jButton2ChonAnh;
    private javax.swing.JButton jButton3Luu;
    private javax.swing.JButton jButton4DoiMatKhau;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel1HienAnhSinhVien;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel4HienTenSinhVien;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel5HienMaSinhVien;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel6HienAnhSinhVien;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable1Diem;
    private javax.swing.JTextField jTextField1GhiChu;
    private javax.swing.JTextPane jTextPane3;
    private javax.swing.JTextPane sotinchitichluy;
    private javax.swing.JTextPane xeploaihoclucthang10;
    // End of variables declaration//GEN-END:variables
private void icon() {
    
    ImageIcon iconGoc2 = new ImageIcon(getClass().getResource("/Style/dowload.png"));
    Image iconThuNho2 = iconGoc2.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton2ChonAnh.setIcon(new ImageIcon(iconThuNho2));
    jButton2ChonAnh.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton2ChonAnh.setIconTextGap(5);

    ImageIcon iconGoc3 = new ImageIcon(getClass().getResource("/Style/save.png"));
    Image iconThuNho3 = iconGoc3.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton3Luu.setIcon(new ImageIcon(iconThuNho3));
    jButton3Luu.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton3Luu.setIconTextGap(5);
    
    ImageIcon iconGoc6 = new ImageIcon(getClass().getResource("/Style/leave.png"));
    Image iconThuNho6 = iconGoc6.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    DangXuat.setIcon(new ImageIcon(iconThuNho6));
    DangXuat.setHorizontalTextPosition(SwingConstants.RIGHT);
    DangXuat.setIconTextGap(5);
    
    ImageIcon iconGoc7 = new ImageIcon(getClass().getResource("/Style/change.png"));
    Image iconThuNho7 = iconGoc7.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton4DoiMatKhau.setIcon(new ImageIcon(iconThuNho7));
    jButton4DoiMatKhau.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton4DoiMatKhau.setIconTextGap(5);
    
}
private void tuyChinhGiaoDien() {
    // Đặt màu nền nếu bạn muốn giao diện đồng bộ
    this.getContentPane().setBackground(Color.decode("#F5F5FA"));
}
}
