/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GiaoDien;
import javax.swing.table.DefaultTableModel;
import Style.GiaoDienMacDinh;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.util.Map;
import javax.swing.ImageIcon;

/**
 *
 * @author thuan
 */
public class Admin extends javax.swing.JFrame {
private String getMaCNByTen(String tenCN) {
    String maCN = null;
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) return null;
    
    try {
        String sql = "SELECT MaCN FROM ChuyenNganh WHERE TenCN = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenCN);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) maCN = rs.getString("MaCN");
        
        rs.close();
        pst.close();
    } catch (SQLException e) { e.printStackTrace(); }
    return maCN;
}

private String getMaMonByTen(String tenMon) {
    String maMon = null;
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) return null;
    
    try {
        String sql = "SELECT MaMon FROM MonHoc WHERE TenMon = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenMon);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) maMon = rs.getString("MaMon");

        rs.close();
        pst.close();
    } catch (SQLException e) { e.printStackTrace(); }
    return maMon;
}
    /**
     * Creates new form Admin
     */
    public Admin() {
        initComponents();
        loadHP();
        loadDataToTableLopHocPhan();
        loadDataToTableChuongTrinhDaoTao();
        loadCCDT();
        loadDataToTableGiangVien();
        loadGV();
        loadDataToTableSinhVien();
        loadSinhVien();
        GiaoDienMacDinh.caiDatFlatLaf();
        icon();
        tuyChinhGiaoDien();
    }
    private void loadSinhVien() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        // 1. Load dữ liệu cho jComboBox4GioiTinh (Giới tính)
        jComboBox4GioiTInh.removeAllItems();
        jComboBox4GioiTInh.addItem("-- Chọn giới tính --");
        jComboBox4GioiTInh.addItem("Nam");
        jComboBox4GioiTInh.addItem("Nữ");

        // 2. Load dữ liệu cho jComboBox6TrangThai (Trạng thái)
        jComboBox6TrangTHai.removeAllItems();
        jComboBox6TrangTHai.addItem("-- Chọn trạng thái --");
        jComboBox6TrangTHai.addItem("DangHoc");
        jComboBox6TrangTHai.addItem("DaTotNghiep");
        jComboBox6TrangTHai.addItem("ThoiHoc");

        // 3. Load dữ liệu cho jComboBox5Lop (Danh sách lớp)
        String sql = "SELECT TenLop FROM Lop";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        jComboBox5Lop.removeAllItems();
        jComboBox5Lop.addItem("-- Chọn lớp --");

        while (rs.next()) {
            jComboBox5Lop.addItem(rs.getString("TenLop"));
        }

        rs.close();
        pst.close();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu Sinh Viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
    private void hienThiAnhSV() {
    int selectedRow = jTable3SinhVien.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một sinh viên từ bảng!");
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable3SinhVien.getModel();
    Object imageDataObj = model.getValueAt(selectedRow, 12); // Cột 12 chứa ảnh

    try {
        if (imageDataObj != null && imageDataObj instanceof byte[]) {
            byte[] imageData = (byte[]) imageDataObj;
            if (imageData.length > 0) {
                ImageIcon imageIcon = new ImageIcon(imageData);
                Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                HienThiAnhSV.setIcon(new ImageIcon(image));
            } else {
                HienThiAnhSV.setIcon(null); // Nếu ảnh rỗng, xóa ảnh hiển thị
            }
        } else {
            HienThiAnhSV.setIcon(null); // Nếu không có ảnh, xóa ảnh hiển thị
        }
    } catch (Exception e) {
        HienThiAnhSV.setIcon(null);
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi hiển thị ảnh: " + e.getMessage());
    }
}
    private void loadDataToTableSinhVien() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "SELECT SV.MaSV, SV.HoTen, SV.NgaySinh, SV.GioiTinh, SV.Email, SV.SDT, SV.DiaChi, " +
                     "SV.NgayVaoHoc, SV.TrangThai, SV.CCCD, SV.GhiChu, L.TenLop, SV.Anh, TK.TenDangNhap, TK.MatKhau " +
                     "FROM SinhVien SV " +
                     "JOIN Lop L ON SV.MaLop = L.MaLop " +
                     "LEFT JOIN TaiKhoan TK ON SV.MaSV = TK.MaLienKet";

        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) jTable3SinhVien.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            Object[] row = {
                rs.getString("MaSV"),
                rs.getString("HoTen"),
                rs.getDate("NgaySinh"),
                rs.getString("GioiTinh"),
                rs.getString("Email"),
                rs.getString("SDT"),
                rs.getString("DiaChi"),
                rs.getDate("NgayVaoHoc"),
                rs.getString("TrangThai"),
                rs.getString("CCCD"),
                rs.getString("GhiChu"),
                rs.getString("TenLop"),
                rs.getBytes("Anh"), // Lấy dữ liệu ảnh dưới dạng byte[]
                rs.getString("TenDangNhap"), // Lấy tài khoản
                rs.getString("MatKhau") // Lấy mật khẩu
            };
            model.addRow(row);
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu sinh viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
    private void loadGV() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        // 1. Load dữ liệu cho jComboBox1Khoa (Tên Khoa)
        String sql1 = "SELECT TenKhoa FROM Khoa";
        PreparedStatement pst1 = conn.prepareStatement(sql1);
        ResultSet rs1 = pst1.executeQuery();
        
        jComboBox1Khoa.removeAllItems();
        jComboBox1Khoa.addItem("-- Chọn tên khoa --");
        while (rs1.next()) {
            jComboBox1Khoa.addItem(rs1.getString("TenKhoa"));
        }
        rs1.close();
        pst1.close();
        
        // 2. Load dữ liệu cho jComboBox2MonHoc (Tên môn học)
        String sql2 = "SELECT TenMon FROM MonHoc";
        PreparedStatement pst2 = conn.prepareStatement(sql2);
        ResultSet rs2 = pst2.executeQuery();
        
        jComboBox2MonHoc.removeAllItems();
        jComboBox2MonHoc.addItem("-- Chọn tên môn học --");
        while (rs2.next()) {
            jComboBox2MonHoc.addItem(rs2.getString("TenMon"));
        }
        rs2.close();
        pst2.close();
        
        // 3. Load dữ liệu cho jComboBox3GioiTinh (Giới tính)
        jComboBox3GioiTinh.removeAllItems();
        jComboBox3GioiTinh.addItem("-- Chọn giới tính --");
        jComboBox3GioiTinh.addItem("Nam");
        jComboBox3GioiTinh.addItem("Nữ");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu Giảng Viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
    private void loadDataToTableGiangVien() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "SELECT GV.MaGV, GV.HoTen, GV.NgaySinh, K.TenKhoa, GV.BoMon, GV.GioiTinh, GV.Email, GV.SDT, " +
                     "GV.DiaChi, GV.NgayVaoLam, GV.TrinhDo, GV.ChucVu, GV.CCCD, GV.GhiChu, TK.TenDangNhap, TK.MatKhau, GV.Anh " +
                     "FROM GiangVien GV " +
                     "JOIN Khoa K ON GV.MaKhoa = K.MaKhoa " +
                     "LEFT JOIN TaiKhoan TK ON GV.MaGV = TK.MaLienKet";

        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) jTable1GiangVien.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            Object[] row = {
                rs.getString("MaGV"),
                rs.getString("HoTen"),
                rs.getDate("NgaySinh"),
                rs.getString("TenKhoa"),
                rs.getString("BoMon"),
                rs.getString("GioiTinh"),
                rs.getString("Email"),
                rs.getString("SDT"),
                rs.getString("DiaChi"),
                rs.getDate("NgayVaoLam"),
                rs.getString("TrinhDo"),
                rs.getString("ChucVu"),
                rs.getString("CCCD"),
                rs.getString("GhiChu"),
                rs.getString("TenDangNhap"),
                rs.getString("MatKhau"),
                rs.getBytes("Anh") // Lấy dữ liệu ảnh dưới dạng byte[]
            };
            model.addRow(row);
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu giảng viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
    private void hienThiAnhGV() {
    int selectedRow = jTable1GiangVien.getSelectedRow();
    
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một giảng viên từ bảng!");
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable1GiangVien.getModel();
    Object imageDataObj = model.getValueAt(selectedRow, 16); // Cột 16 chứa ảnh

    try {
        if (imageDataObj != null && imageDataObj instanceof byte[]) {
            byte[] imageData = (byte[]) imageDataObj;
            if (imageData.length > 0) {
                ImageIcon imageIcon = new ImageIcon(imageData);
                Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                HienThiAnhGV.setIcon(new ImageIcon(image));
            } else {
                HienThiAnhGV.setIcon(null); // Nếu ảnh rỗng, xóa ảnh hiển thị
            }
        } else {
            HienThiAnhGV.setIcon(null); // Nếu không có ảnh, xóa ảnh hiển thị
        }
    } catch (Exception e) {
        HienThiAnhGV.setIcon(null);
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi hiển thị ảnh: " + e.getMessage());
    }
}
    private void loadCCDT() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        // 1. Load dữ liệu cho jComboBox1MaKH (Mã khóa học)
        String sql1 = "SELECT MaKhoaHoc FROM KhoaHoc";
        PreparedStatement pst1 = conn.prepareStatement(sql1);
        ResultSet rs1 = pst1.executeQuery();
        
        jComboBox1MaKH.removeAllItems();
        jComboBox1MaKH.addItem("-- Chọn mã khóa học --");
        while (rs1.next()) {
            jComboBox1MaKH.addItem(rs1.getString("MaKhoaHoc"));
        }
        rs1.close();
        pst1.close();
        
        // 2. Load dữ liệu cho jComboBox2TenCN (Tên chuyên ngành)
        String sql2 = "SELECT TenCN FROM ChuyenNganh";
        PreparedStatement pst2 = conn.prepareStatement(sql2);
        ResultSet rs2 = pst2.executeQuery();
        
        jComboBox2TenCN.removeAllItems();
        jComboBox2TenCN.addItem("-- Chọn tên chuyên ngành --");
        while (rs2.next()) {
            jComboBox2TenCN.addItem(rs2.getString("TenCN"));
        }
        rs2.close();
        pst2.close();
        
        // 3. Load dữ liệu cho jComboBox3TenMH (Tên môn học)
        String sql3 = "SELECT TenMon FROM MonHoc";
        PreparedStatement pst3 = conn.prepareStatement(sql3);
        ResultSet rs3 = pst3.executeQuery();
        
        jComboBox3TenMH.removeAllItems();
        jComboBox3TenMH.addItem("-- Chọn tên môn học --");
        while (rs3.next()) {
            jComboBox3TenMH.addItem(rs3.getString("TenMon"));
        }
        rs3.close();
        pst3.close();
        
        // 4. Load dữ liệu cho jComboBox4MaNH (Mã năm học)
        String sql4 = "SELECT MaNHKK FROM NamHocKiHoc";
        PreparedStatement pst4 = conn.prepareStatement(sql4);
        ResultSet rs4 = pst4.executeQuery();
        
        jComboBox4MaNH.removeAllItems();
        jComboBox4MaNH.addItem("-- Chọn mã năm học --");
        while (rs4.next()) {
            jComboBox4MaNH.addItem(rs4.getString("MaNHKK"));
        }
        rs4.close();
        pst4.close();
        
        // 5. Load dữ liệu cho jComboBox5BatBuoc (Bắt buộc)
        jComboBox5BatBuoc.removeAllItems();
        jComboBox5BatBuoc.addItem("-- Chọn trạng thái --");
        jComboBox5BatBuoc.addItem("✔ Bắt buộc");
        jComboBox5BatBuoc.addItem("✘ Không bắt buộc");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu Chương Trình Đào Tạo: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
    private void loadDataToTableChuongTrinhDaoTao() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }

    try {
        // Truy vấn JOIN để lấy thông tin cần thiết
        String sql = "SELECT CTDT.MaCTDT, CTDT.MaKhoaHoc, CN.TenCN, MH.TenMon, CTDT.MaNHKK, CTDT.BatBuoc " +
                     "FROM ChuongTrinhDaoTao CTDT " +
                     "JOIN ChuyenNganh CN ON CTDT.MaCN = CN.MaCN " +
                     "JOIN MonHoc MH ON CTDT.MaMon = MH.MaMon";

        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        // Lấy model của jTable2 và xóa dữ liệu cũ
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);

        // Duyệt qua kết quả truy vấn và thêm từng dòng vào model
        while (rs.next()) {
            int maCTDT = rs.getInt("MaCTDT");
            String maKhoaHoc = rs.getString("MaKhoaHoc");
            String tenCN = rs.getString("TenCN");
            String tenMon = rs.getString("TenMon");
            String maNHKK = rs.getString("MaNHKK");
            boolean batBuoc = rs.getBoolean("BatBuoc");

            Object[] row = { maCTDT, maKhoaHoc, tenCN, tenMon, maNHKK, batBuoc ? "✔" : "✘" };
            model.addRow(row);
        }

        // Đóng tài nguyên
        rs.close();
        pst.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu chương trình đào tạo: " + e.getMessage());
    }
}
    private void loadDataToTableLopHocPhan() {
    // Kết nối đến CSDL bằng phương thức kết nối đã định nghĩa
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }

    try {
        // Truy vấn JOIN nhiều bảng để lấy thông tin cần thiết
        String sql = "SELECT LHP.MaLHP, MH.TenMon, L.TenLop, GV.HoTen AS TenGV, NH.NamHoc, NH.KiHoc " +
                     "FROM LopHocPhan LHP " +
                     "JOIN MonHoc MH ON LHP.MaMon = MH.MaMon " +
                     "JOIN Lop L ON LHP.MaLop = L.MaLop " +
                     "JOIN GiangVien GV ON LHP.MaGV = GV.MaGV " +
                     "JOIN NamHocKiHoc NH ON LHP.MaNHKK = NH.MaNHKK";
        
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        // Lấy đối tượng model của jTable4 và xóa dữ liệu cũ
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
        model.setRowCount(0);

        // Duyệt qua kết quả của truy vấn và thêm từng dòng vào model
        while (rs.next()) {
            String maLHP    = rs.getString("MaLHP");
            String tenMon   = rs.getString("TenMon");
            String tenLop   = rs.getString("TenLop");
            String tenGV    = rs.getString("TenGV");
            String namHoc   = rs.getString("NamHoc");
            String kiHoc    = rs.getString("KiHoc");
            
            Object[] row = { maLHP, tenMon, tenLop, tenGV, namHoc, kiHoc };
            model.addRow(row);
        }
        
        // Đóng ResultSet, PreparedStatment và Connection
        rs.close();
        pst.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu học phần: " + e.getMessage());
    }
}
private void loadHP() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }
    
    try {
        // 1. Load dữ liệu cho jComboBox1MaNamHoc (từ bảng namhockihoc - cột MaNHKK)
        String sql1 = "SELECT MaNHKK FROM namhockihoc";
        PreparedStatement pst1 = conn.prepareStatement(sql1);
        ResultSet rs1 = pst1.executeQuery();
        
        jComboBox1MaNamHoc.removeAllItems();
        jComboBox1MaNamHoc.addItem("-- Chọn mã năm học --");
        while (rs1.next()) {
            String maNHKK = rs1.getString("MaNHKK");
            jComboBox1MaNamHoc.addItem(maNHKK);
        }
        rs1.close();
        pst1.close();
        
        // 2. Load dữ liệu cho jComboBox3TenMonHoc (từ bảng monhoc - cột TenMon)
        String sql2 = "SELECT TenMon FROM monhoc";
        PreparedStatement pst2 = conn.prepareStatement(sql2);
        ResultSet rs2 = pst2.executeQuery();
        
        jComboBox3TenMonHoc.removeAllItems();
        jComboBox3TenMonHoc.addItem("-- Chọn tên môn học --");
        while (rs2.next()) {
            String tenMon = rs2.getString("TenMon");
            jComboBox3TenMonHoc.addItem(tenMon);
        }
        rs2.close();
        pst2.close();
        
        // 3. Load dữ liệu cho jComboBox4TenLopHoc (từ bảng lop - cột TenLop)
        String sql3 = "SELECT TenLop FROM lop";
        PreparedStatement pst3 = conn.prepareStatement(sql3);
        ResultSet rs3 = pst3.executeQuery();
        
        jComboBox4TenLopHoc.removeAllItems();
        jComboBox4TenLopHoc.addItem("-- Chọn tên lớp học --");
        while (rs3.next()) {
            String tenLop = rs3.getString("TenLop");
            jComboBox4TenLopHoc.addItem(tenLop);
        }
        rs3.close();
        pst3.close();
        
        // 4. Load dữ liệu cho jComboBox5TenGiangVien (từ bảng giangvien - cột HoTen)
        String sql4 = "SELECT HoTen FROM giangvien";
        PreparedStatement pst4 = conn.prepareStatement(sql4);
        ResultSet rs4 = pst4.executeQuery();
        
        jComboBox5TenGiangVien.removeAllItems();
        jComboBox5TenGiangVien.addItem("-- Chọn tên giảng viên --");
        while (rs4.next()) {
            String hoTen = rs4.getString("HoTen");
            jComboBox5TenGiangVien.addItem(hoTen);
        }
        rs4.close();
        pst4.close();
        
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu: " + e.getMessage());
    } finally {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1GiangVien = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        MaGV = new javax.swing.JTextPane();
        jScrollPane8 = new javax.swing.JScrollPane();
        TenGV = new javax.swing.JTextPane();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jComboBox1Khoa = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        jComboBox2MonHoc = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        jComboBox3GioiTinh = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        Email = new javax.swing.JTextPane();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane10 = new javax.swing.JScrollPane();
        SDT = new javax.swing.JTextPane();
        reset = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        DiaChi = new javax.swing.JTextPane();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        NgayVaoLam = new javax.swing.JTextPane();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        TrinHDo = new javax.swing.JTextPane();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        ChuCVU = new javax.swing.JTextPane();
        jLabel23 = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        CCCD = new javax.swing.JTextPane();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        GhiCHus = new javax.swing.JTextPane();
        ThemGV = new javax.swing.JButton();
        SuaGV = new javax.swing.JButton();
        XoaGV = new javax.swing.JButton();
        HienThiGV = new javax.swing.JButton();
        TImKiem = new javax.swing.JButton();
        ChonAnh = new javax.swing.JButton();
        jLabel26 = new javax.swing.JLabel();
        jScrollPane17 = new javax.swing.JScrollPane();
        TaiKhoan = new javax.swing.JTextPane();
        jLabel27 = new javax.swing.JLabel();
        jScrollPane18 = new javax.swing.JScrollPane();
        MatKhau = new javax.swing.JTextPane();
        HienThiAnhGV = new javax.swing.JLabel();
        jScrollPane22 = new javax.swing.JScrollPane();
        NgaySinh = new javax.swing.JTextPane();
        jLabel25 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3SinhVien = new javax.swing.JTable();
        jLabel29 = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        MSV = new javax.swing.JTextPane();
        jLabel30 = new javax.swing.JLabel();
        jScrollPane20 = new javax.swing.JScrollPane();
        HoTen = new javax.swing.JTextPane();
        jLabel31 = new javax.swing.JLabel();
        jScrollPane21 = new javax.swing.JScrollPane();
        NgaySinhSV = new javax.swing.JTextPane();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jScrollPane23 = new javax.swing.JScrollPane();
        emailSV = new javax.swing.JTextPane();
        jLabel34 = new javax.swing.JLabel();
        jScrollPane24 = new javax.swing.JScrollPane();
        SDTSV = new javax.swing.JTextPane();
        jLabel35 = new javax.swing.JLabel();
        jScrollPane25 = new javax.swing.JScrollPane();
        DiaChiSV = new javax.swing.JTextPane();
        jScrollPane26 = new javax.swing.JScrollPane();
        NgayNhapHoc = new javax.swing.JTextPane();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jScrollPane28 = new javax.swing.JScrollPane();
        CCCDSV = new javax.swing.JTextPane();
        jLabel38 = new javax.swing.JLabel();
        jScrollPane29 = new javax.swing.JScrollPane();
        GhiChuSV = new javax.swing.JTextPane();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        HienThiAnhSV = new javax.swing.JLabel();
        ChonAnhSV = new javax.swing.JButton();
        TimKiemSV = new javax.swing.JButton();
        ThemSV = new javax.swing.JButton();
        SuaSV = new javax.swing.JButton();
        XoaSV = new javax.swing.JButton();
        HienThiSV = new javax.swing.JButton();
        ResetSV = new javax.swing.JButton();
        jComboBox4GioiTInh = new javax.swing.JComboBox<>();
        jComboBox5Lop = new javax.swing.JComboBox<>();
        jComboBox6TrangTHai = new javax.swing.JComboBox<>();
        jLabel28 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jScrollPane27 = new javax.swing.JScrollPane();
        TaiKhoanSV = new javax.swing.JTextPane();
        jScrollPane30 = new javax.swing.JScrollPane();
        MatKhauSV = new javax.swing.JTextPane();
        Diem = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1MaNamHoc = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jComboBox3TenMonHoc = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jComboBox4TenLopHoc = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jComboBox5TenGiangVien = new javax.swing.JComboBox<>();
        ThemLHP = new javax.swing.JButton();
        SuaLHP = new javax.swing.JButton();
        Xoas = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        HienThi = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1MaLHP = new javax.swing.JTextPane();
        jButton11 = new javax.swing.JButton();
        TimKiem = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jPanel4xoa = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextPane1MaCCDT = new javax.swing.JTextPane();
        jLabel6 = new javax.swing.JLabel();
        jComboBox1MaKH = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        jComboBox2TenCN = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jComboBox3TenMH = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jComboBox4MaNH = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jComboBox5BatBuoc = new javax.swing.JComboBox<>();
        jButton3Them = new javax.swing.JButton();
        jButton4Sua = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        HienTHi = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1GiangVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã Giảng Viên", "Tên Giảng Viên", "Ngày Sinh", "Khoa", "Bộ Môn", "Giới tính", "Email", "Số DT", "Địa chỉ", "Ngày Vào Làm", "Trình Độ", "Chức vụ", "CCCD", "Ghi chú", "Tài Khoản", "Mật Khẩu", "Ảnh"
            }
        ));
        jScrollPane1.setViewportView(jTable1GiangVien);

        jLabel12.setText("Mã Giảng Viên");

        jScrollPane7.setViewportView(MaGV);

        jScrollPane8.setViewportView(TenGV);

        jLabel13.setText("Họ và Tên");

        jLabel14.setText("Khoa");

        jComboBox1Khoa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel15.setText("Môn");

        jComboBox2MonHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel16.setText("Giới tính");

        jComboBox3GioiTinh.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel17.setText("Email");

        jScrollPane9.setViewportView(Email);

        jLabel18.setText("SDT");

        jScrollPane10.setViewportView(SDT);

        reset.setText("Reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        jLabel19.setText("Địa chỉ");

        jScrollPane11.setViewportView(DiaChi);

        jLabel20.setText("Ngày vào làm");

        jScrollPane12.setViewportView(NgayVaoLam);

        jLabel21.setText("Trình Độ");

        jScrollPane13.setViewportView(TrinHDo);

        jLabel22.setText("Chức Vụ");

        jScrollPane14.setViewportView(ChuCVU);

        jLabel23.setText("Số CCCD");

        jScrollPane15.setViewportView(CCCD);

        jLabel24.setText("Ghi chú");

        jScrollPane16.setViewportView(GhiCHus);

        ThemGV.setText("Thêm");
        ThemGV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemGVActionPerformed(evt);
            }
        });

        SuaGV.setText("Sửa");
        SuaGV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuaGVActionPerformed(evt);
            }
        });

        XoaGV.setText("Xóa");
        XoaGV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XoaGVActionPerformed(evt);
            }
        });

        HienThiGV.setText("Hiển thị");
        HienThiGV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HienThiGVActionPerformed(evt);
            }
        });

        TImKiem.setText("Tìm Kiếm");
        TImKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TImKiemActionPerformed(evt);
            }
        });

        ChonAnh.setText("Chọn ảnh");
        ChonAnh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChonAnhActionPerformed(evt);
            }
        });

        jLabel26.setText("Tài khoản");

        jScrollPane17.setViewportView(TaiKhoan);

        jLabel27.setText("Mật khẩu");

        jScrollPane18.setViewportView(MatKhau);

        HienThiAnhGV.setText("Ảnh Giảng Viên");

        jScrollPane22.setViewportView(NgaySinh);

        jLabel25.setText("Ngày Sinh");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1065, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane17)
                        .addComponent(jLabel27, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane18))
                    .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane12, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                    .addComponent(jLabel13)
                    .addComponent(jLabel20)
                    .addComponent(HienThiAnhGV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jComboBox1Khoa, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(HienThiGV, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ChonAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jComboBox2MonHoc, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox3GioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(87, 87, 87)
                        .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(SuaGV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
                                .addComponent(ThemGV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane15)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TImKiem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(XoaGV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(jScrollPane10)
                        .addComponent(jScrollPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 116, Short.MAX_VALUE)
                        .addComponent(jLabel25, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane9)
                    .addComponent(jScrollPane16)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(reset))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addComponent(jLabel12)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createSequentialGroup()
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jLabel13)
                                                .addComponent(jLabel15)
                                                .addComponent(jLabel16)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jLabel18)
                                            .addComponent(jLabel17)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(jComboBox1Khoa, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox2MonHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox3GioiTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(jScrollPane10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(reset))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel19)
                                    .addComponent(jLabel20)
                                    .addComponent(jLabel21)
                                    .addComponent(jLabel22))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel24, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane16, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel25)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel26)
                        .addGap(7, 7, 7)
                        .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(jLabel27)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(HienThiAnhGV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ChonAnh)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(ThemGV)
                                .addComponent(XoaGV)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(HienThiGV)
                            .addComponent(SuaGV)
                            .addComponent(TImKiem))))
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Quản lý Giảng Viên", jPanel1);

        jTable3SinhVien.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sinh viên", "Họ và Tên", "Ngày sinh", "Giới tính", "Email", "Sdt", "Địa chỉ", "Ngày nhập học", "Trạng thái", "CCCD", "Ghi chú", "Lớp", "Ảnh", "Tài khoản", "Mật khẩu"
            }
        ));
        jScrollPane3.setViewportView(jTable3SinhVien);

        jLabel29.setText("Mã Sinh Viên");

        jScrollPane19.setViewportView(MSV);

        jLabel30.setText("Họ và Tên ");

        jScrollPane20.setViewportView(HoTen);

        jLabel31.setText("Ngày Sinh");

        jScrollPane21.setViewportView(NgaySinhSV);

        jLabel32.setText("Giới Tính");

        jLabel33.setText("Email");

        jScrollPane23.setViewportView(emailSV);

        jLabel34.setText("SDT");

        jScrollPane24.setViewportView(SDTSV);

        jLabel35.setText("Địa chỉ");

        jScrollPane25.setViewportView(DiaChiSV);

        jScrollPane26.setViewportView(NgayNhapHoc);

        jLabel36.setText("Ngày nhập học");

        jLabel37.setText("Trạng Thái");

        jScrollPane28.setViewportView(CCCDSV);

        jLabel38.setText("CCCD");

        jScrollPane29.setViewportView(GhiChuSV);

        jLabel39.setText("Ghi chú");

        jLabel40.setText("Lớp");

        HienThiAnhSV.setText("Ảnh Sinh Viên");

        ChonAnhSV.setText("Chọn ảnh");
        ChonAnhSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChonAnhSVActionPerformed(evt);
            }
        });

        TimKiemSV.setText("Tìm Kiếm");
        TimKiemSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TimKiemSVActionPerformed(evt);
            }
        });

        ThemSV.setText("Thêm");
        ThemSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemSVActionPerformed(evt);
            }
        });

        SuaSV.setText("Sửa");
        SuaSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuaSVActionPerformed(evt);
            }
        });

        XoaSV.setText("Xóa");
        XoaSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XoaSVActionPerformed(evt);
            }
        });

        HienThiSV.setText("Hiển thị");
        HienThiSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HienThiSVActionPerformed(evt);
            }
        });

        ResetSV.setText("Reset");
        ResetSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ResetSVActionPerformed(evt);
            }
        });

        jComboBox4GioiTInh.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox5Lop.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox6TrangTHai.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel28.setText("Tài Khoản");

        jLabel41.setText("Mật Khẩu");

        jScrollPane27.setViewportView(TaiKhoanSV);

        jScrollPane30.setViewportView(MatKhauSV);

        Diem.setText("Điểm");
        Diem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1065, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel29)
                    .addComponent(jScrollPane19)
                    .addComponent(HienThiAnhSV, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel30)
                    .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(TimKiemSV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ChonAnhSV, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel31)
                            .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel32)
                            .addComponent(jComboBox4GioiTInh, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel33)
                            .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel34)
                            .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel35)
                            .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel36)
                            .addComponent(jScrollPane26, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                            .addComponent(jLabel28, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel37)
                            .addComponent(jComboBox6TrangTHai, 0, 132, Short.MAX_VALUE)
                            .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane30))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel38)
                            .addComponent(jScrollPane28, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ThemSV))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel39)
                            .addComponent(jScrollPane29, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(SuaSV))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox5Lop, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel40)
                                    .addComponent(HienThiSV))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(ResetSV)
                        .addComponent(XoaSV))
                    .addComponent(Diem))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel30)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel31)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel32)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jComboBox4GioiTInh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel33)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel34)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel35)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ResetSV))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel36, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel37)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox6TrangTHai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel38)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane28, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel39)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel40)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox5Lop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(XoaSV)))
                            .addComponent(ChonAnhSV))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(TimKiemSV)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel28)
                                    .addComponent(jLabel41))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jScrollPane27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane30, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(ThemSV)
                                .addComponent(SuaSV)
                                .addComponent(HienThiSV)
                                .addComponent(Diem)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(HienThiAnhSV, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(18, 18, 18)))
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Quản Lý Sinh Viên", jPanel2);

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã học phần", "Môn học", " Lớp học", "Giảng Viên", "Năm học", "Kì học"
            }
        ));
        jScrollPane4.setViewportView(jTable4);

        jLabel1.setText("Năm học");

        jComboBox1MaNamHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setText("Môn học");

        jComboBox3TenMonHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setText("Lớp học");

        jComboBox4TenLopHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel5.setText("Giảng Viên");

        jComboBox5TenGiangVien.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox5TenGiangVien.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5TenGiangVienActionPerformed(evt);
            }
        });

        ThemLHP.setText("Thêm Lớp học phần");
        ThemLHP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ThemLHPActionPerformed(evt);
            }
        });

        SuaLHP.setText("Sửa");
        SuaLHP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SuaLHPActionPerformed(evt);
            }
        });

        Xoas.setText("Xóa");
        Xoas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                XoasActionPerformed(evt);
            }
        });

        jButton5.setText("Reset");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("Thêm năm học");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("Thêm Khóa học");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("Thêm Khoa");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        jButton9.setText("Thêm Lớp");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        HienThi.setText("Hiển thị");
        HienThi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HienThiActionPerformed(evt);
            }
        });

        jLabel11.setText("Mã học phần");

        jScrollPane2.setViewportView(jTextPane1MaLHP);

        jButton11.setText("Thêm chuyên ngành");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        TimKiem.setText("Tìm Kiếm");
        TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TimKiemActionPerformed(evt);
            }
        });

        jButton2.setText("Thêm Môn học");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane4)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jComboBox1MaNamHoc, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1)
                            .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jComboBox4TenLopHoc, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jComboBox3TenMonHoc, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton11))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jComboBox5TenGiangVien, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jButton2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jButton9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(TimKiem, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(ThemLHP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(SuaLHP, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Xoas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(HienThi, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(176, 176, 176)
                        .addComponent(jButton5)
                        .addContainerGap())))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jButton5))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel11)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel3Layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jComboBox3TenMonHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox5TenGiangVien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(ThemLHP))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jComboBox1MaNamHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox4TenLopHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(TimKiem)
                                    .addComponent(SuaLHP))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton6)
                            .addComponent(jButton9)
                            .addComponent(jButton8)
                            .addComponent(Xoas))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton11)
                            .addComponent(jButton7)
                            .addComponent(jButton2)
                            .addComponent(HienThi))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 446, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Quản lý lớp học phần", jPanel3);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Mã CCDT", "Mã Khóa học", "Tên Chuyên Ngành", "Tên Môn học", "Mã Năm học", "Bắt buộc"
            }
        ));
        jScrollPane5.setViewportView(jTable2);

        jLabel2.setText("Mã Chương trình đạo tạo");

        jScrollPane6.setViewportView(jTextPane1MaCCDT);

        jLabel6.setText("Mã Khóa học");

        jComboBox1MaKH.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setText("Tên Chuyên Ngành");

        jComboBox2TenCN.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel8.setText("Tên Môn học");

        jComboBox3TenMH.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel9.setText("Mã Năm học");

        jComboBox4MaNH.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setText("Bắt buộc");

        jComboBox5BatBuoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jButton3Them.setText("Thêm");
        jButton3Them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ThemActionPerformed(evt);
            }
        });

        jButton4Sua.setText("Sửa");
        jButton4Sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4SuaActionPerformed(evt);
            }
        });

        jButton10.setText("Xóa");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton12.setText("Reset");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        HienTHi.setText("Hiển thị");
        HienTHi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HienTHiActionPerformed(evt);
            }
        });

        jButton14.setText("Tìm Kiếm");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4xoaLayout = new javax.swing.GroupLayout(jPanel4xoa);
        jPanel4xoa.setLayout(jPanel4xoaLayout);
        jPanel4xoaLayout.setHorizontalGroup(
            jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4xoaLayout.createSequentialGroup()
                .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane5)
                    .addGroup(jPanel4xoaLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane6)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jButton3Them))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jComboBox1MaKH, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton10))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jComboBox2TenCN, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(HienTHi))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jComboBox3TenMH, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton4Sua))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox4MaNH, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton12))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton14)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox5BatBuoc, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 133, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel4xoaLayout.setVerticalGroup(
            jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4xoaLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBox1MaKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox2TenCN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox3TenMH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox4MaNH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jComboBox5BatBuoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel4xoaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton3Them)
                    .addComponent(jButton10)
                    .addComponent(HienTHi)
                    .addComponent(jButton4Sua)
                    .addComponent(jButton12)
                    .addComponent(jButton14))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Chương Trình Đào Tạo", jPanel4xoa);

        jButton1.setText("Thoát");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jButton1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void XoasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XoasActionPerformed
// Lấy mã học phần từ ô jTextPane1MaLHP
    String maLHP = jTextPane1MaLHP.getText().trim();
    
    if(maLHP.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập mã học phần cần xóa!");
        return;
    }
    
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        String sql = "DELETE FROM LopHocPhan WHERE MaLHP = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, maLHP);
        
        int rowsDeleted = pst.executeUpdate();
        if(rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Xóa học phần thành công!");
            loadDataToTableLopHocPhan();
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy học phần để xóa!");
        }
        
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi xóa học phần: " + e.getMessage());
    } finally {
        try { conn.close(); } catch(SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_XoasActionPerformed

    private void jComboBox5TenGiangVienActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5TenGiangVienActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox5TenGiangVienActionPerformed

    private void SuaLHPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuaLHPActionPerformed
// Lấy dữ liệu từ control
    String maLHP = jTextPane1MaLHP.getText().trim();
    String selectedMaNHKK = (String) jComboBox1MaNamHoc.getSelectedItem();
    String tenMon = (String) jComboBox3TenMonHoc.getSelectedItem();
    String tenLop = (String) jComboBox4TenLopHoc.getSelectedItem();
    String tenGV  = (String) jComboBox5TenGiangVien.getSelectedItem();
    
    if(maLHP.isEmpty() || selectedMaNHKK == null || tenMon == null || tenLop == null || tenGV == null ||
       maLHP.equals("") || selectedMaNHKK.startsWith("--") || tenMon.startsWith("--") ||
       tenLop.startsWith("--") || tenGV.startsWith("--")) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin để cập nhật!");
        return;
    }
    
    // Chuyển đổi tên thành mã
    String maMon = getMaMonByTen(tenMon);
    String maLop = getMaLopByTen(tenLop);
    String maGV  = getMaGVByTen(tenGV);
    
    if(maMon == null || maLop == null || maGV == null) {
        JOptionPane.showMessageDialog(this, "Không xác định được mã của một số trường!");
        return;
    }
    
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        String sql = "UPDATE LopHocPhan SET MaMon = ?, MaLop = ?, MaGV = ?, MaNHKK = ? WHERE MaLHP = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        
        pst.setString(1, maMon);
        pst.setString(2, maLop);
        pst.setString(3, maGV);
        pst.setString(4, selectedMaNHKK);
        pst.setString(5, maLHP);
        
        int rowsUpdated = pst.executeUpdate();
        if(rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Cập nhật học phần thành công!");
            loadDataToTableLopHocPhan();
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy học phần cần cập nhật!");
        }
        
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi cập nhật học phần: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_SuaLHPActionPerformed

private String getMaLopByTen(String tenLop) {
    String maLop = null;
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return null;
    }
    
    try {
        String sql = "SELECT MaLop FROM Lop WHERE TenLop = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenLop);
        ResultSet rs = pst.executeQuery();
        
        if(rs.next()){
            maLop = rs.getString("MaLop");
        }
        
        rs.close();
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi lấy MaLop: " + e.getMessage());
    } finally {
        try { conn.close(); } catch(SQLException ex) { ex.printStackTrace(); }
    }
    
    return maLop;
}
private String getMaGVByTen(String tenGV) {
    String maGV = null;
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return null;
    }
    
    try {
        String sql = "SELECT MaGV FROM GiangVien WHERE HoTen = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenGV);
        ResultSet rs = pst.executeQuery();
        
        if(rs.next()){
            maGV = rs.getString("MaGV");
        }
        
        rs.close();
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi lấy MaGV: " + e.getMessage());
    } finally {
        try { conn.close(); } catch(SQLException ex) { ex.printStackTrace(); }
    }
    
    return maGV;
}
    private void ThemLHPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemLHPActionPerformed
// Lấy dữ liệu từ các control
    String maLHP = jTextPane1MaLHP.getText().trim();
    String selectedMaNHKK = (String) jComboBox1MaNamHoc.getSelectedItem();  // Mã năm học đã đổ trực tiếp
    String tenMon = (String) jComboBox3TenMonHoc.getSelectedItem();
    String tenLop = (String) jComboBox4TenLopHoc.getSelectedItem();
    String tenGV  = (String) jComboBox5TenGiangVien.getSelectedItem();
    
    // Kiểm tra nhập rỗng
    if(maLHP.isEmpty() || selectedMaNHKK == null || tenMon == null || tenLop == null || tenGV == null ||
       maLHP.equals("") || selectedMaNHKK.startsWith("--") || tenMon.startsWith("--") ||
       tenLop.startsWith("--") || tenGV.startsWith("--")) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        return;
    }
    
    // Chuyển đổi tên thành mã
    String maMon = getMaMonByTen(tenMon);
    String maLop = getMaLopByTen(tenLop);
    String maGV  = getMaGVByTen(tenGV);
    
    if(maMon == null || maLop == null || maGV == null) {
        JOptionPane.showMessageDialog(this, "Không xác định được mã của một số trường!");
        return;
    }
    
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        String sql = "INSERT INTO LopHocPhan (MaLHP, MaMon, MaLop, MaGV, MaNHKK) VALUES (?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        
        pst.setString(1, maLHP);
        pst.setString(2, maMon);
        pst.setString(3, maLop);
        pst.setString(4, maGV);
        pst.setString(5, selectedMaNHKK);
        
        int rowsInserted = pst.executeUpdate();
        if(rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Thêm học phần thành công!");
            // Gọi hàm cập nhật bảng hiển thị nếu có.
            loadDataToTableLopHocPhan();
        } else {
            JOptionPane.showMessageDialog(this, "Thêm học phần thất bại!");
        }
        
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi thêm học phần: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_ThemLHPActionPerformed

    private void HienThiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HienThiActionPerformed
// Lấy chỉ số dòng được chọn trên bảng jTable4
    int selectedRow = jTable4.getSelectedRow();
    
    // Nếu chưa chọn dòng nào, thông báo cho người dùng
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một lớp học phần từ bảng!");
        return;
    }
    
    // Lấy model của jTable4
    DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
    
    // Lấy thông tin từ các cột theo thứ tự:
    // 0: MaLHP, 1: MaNHKK, 2: TenMon, 3: TenLop, 4: TenGV
    String maLHP  = model.getValueAt(selectedRow, 0).toString();
    String maNHKK = model.getValueAt(selectedRow, 1).toString();
    String tenMon = model.getValueAt(selectedRow, 2).toString();
    String tenLop = model.getValueAt(selectedRow, 3).toString();
    String tenGV  = model.getValueAt(selectedRow, 4).toString();
    
    // Hiển thị thông tin lên các control tương ứng
    jTextPane1MaLHP.setText(maLHP);
    jComboBox1MaNamHoc.setSelectedItem(maNHKK);
    jComboBox3TenMonHoc.setSelectedItem(tenMon);
    jComboBox4TenLopHoc.setSelectedItem(tenLop);
    jComboBox5TenGiangVien.setSelectedItem(tenGV);

    }//GEN-LAST:event_HienThiActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
loadDataToTableLopHocPhan();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void TimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TimKiemActionPerformed
// Lấy giá trị tìm kiếm từ các control
    String searchMaLHP = jTextPane1MaLHP.getText().trim();
    String searchMaNHKK = (String) jComboBox1MaNamHoc.getSelectedItem();
    String searchTenMon = (String) jComboBox3TenMonHoc.getSelectedItem();
    String searchTenLop = (String) jComboBox4TenLopHoc.getSelectedItem();
    String searchTenGV  = (String) jComboBox5TenGiangVien.getSelectedItem();
    
    // Kết nối đến CSDL
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        PreparedStatement pst = null;
        String sql = "";
    
        // Nếu có nhập Mã lớp học phần, ưu tiên tìm theo đó.
        if (!searchMaLHP.isEmpty()) {
            sql = "SELECT LHP.MaLHP, LHP.MaNHKK, MH.TenMon, L.TenLop, GV.HoTen AS TenGV " +
                  "FROM LopHocPhan LHP " +
                  "JOIN MonHoc MH ON LHP.MaMon = MH.MaMon " +
                  "JOIN Lop L ON LHP.MaLop = L.MaLop " +
                  "JOIN GiangVien GV ON LHP.MaGV = GV.MaGV " +
                  "WHERE LHP.MaLHP LIKE ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, "%" + searchMaLHP + "%");
        } else {
            // Nếu Mã lớp học phần để trống thì tìm theo các bộ lọc còn lại
            sql = "SELECT LHP.MaLHP, LHP.MaNHKK, MH.TenMon, L.TenLop, GV.HoTen AS TenGV " +
                  "FROM LopHocPhan LHP " +
                  "JOIN MonHoc MH ON LHP.MaMon = MH.MaMon " +
                  "JOIN Lop L ON LHP.MaLop = L.MaLop " +
                  "JOIN GiangVien GV ON LHP.MaGV = GV.MaGV " +
                  "WHERE 1=1";  // điều kiện luôn đúng để tiện bổ sung AND
            // Dùng list để lưu trữ các tham số cho PreparedStatement
            java.util.List<Object> params = new java.util.ArrayList<>();
    
            // Nếu mã năm học được chọn (không phải mục mặc định)
            if (searchMaNHKK != null && !searchMaNHKK.startsWith("--")) {
                sql += " AND LHP.MaNHKK = ?";
                params.add(searchMaNHKK);
            }
            // Nếu chọn tên môn (không phải mục mặc định)
            if (searchTenMon != null && !searchTenMon.startsWith("--")) {
                sql += " AND MH.TenMon LIKE ?";
                params.add("%" + searchTenMon + "%");
            }
            // Nếu chọn tên lớp (không phải mục mặc định)
            if (searchTenLop != null && !searchTenLop.startsWith("--")) {
                sql += " AND L.TenLop LIKE ?";
                params.add("%" + searchTenLop + "%");
            }
            // Nếu chọn tên giảng viên (không phải mục mặc định)
            if (searchTenGV != null && !searchTenGV.startsWith("--")) {
                sql += " AND GV.HoTen LIKE ?";
                params.add("%" + searchTenGV + "%");
            }
    
            pst = conn.prepareStatement(sql);
            // Gán tham số cho PreparedStatement theo thứ tự trong list
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
        }
    
        // Thực hiện truy vấn
        ResultSet rs = pst.executeQuery();
    
        // Lấy model của jTable4 và xoá dữ liệu cũ
        DefaultTableModel model = (DefaultTableModel) jTable4.getModel();
        model.setRowCount(0);
    
        // Duyệt qua ResultSet và đưa dữ liệu vào bảng
        while (rs.next()) {
            Object[] row = {
                rs.getString("MaLHP"),
                rs.getString("MaNHKK"),
                rs.getString("TenMon"),
                rs.getString("TenLop"),
                rs.getString("TenGV")
            };
            model.addRow(row);
        }
    
        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tìm kiếm học phần: " + e.getMessage());
    } finally {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_TimKiemActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
// Tạo đối tượng form NamHoc
    NamHoc namHocForm = new NamHoc();
    
    // Hiển thị form NamHoc
    namHocForm.setVisible(true);
    
    // Nếu muốn đóng form hiện tại khi chuyển qua form NamHoc, bạn có thể gọi:
    // this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
// Tạo đối tượng của form LopHoc
    LopHoc lopHocForm = new LopHoc();
    
    // Hiển thị form LopHoc
    lopHocForm.setVisible(true);
    
    // Nếu bạn muốn đóng form hiện tại sau khi chuyển qua form LopHoc, uncomment dòng dưới:
    // this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
// Tạo đối tượng form Khoa
    Khoa khoaForm = new Khoa();
    
    // Hiển thị form Khoa
    khoaForm.setVisible(true);
    
    // Nếu muốn đóng form hiện tại, uncomment dòng dưới:
    // this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
// Tạo đối tượng form ChuyenNganh
    ChuyenNganh chuyenNganhForm = new ChuyenNganh();
    
    // Hiển thị form ChuyenNganh
    chuyenNganhForm.setVisible(true);
    
    // Nếu muốn đóng form hiện tại, uncomment dòng dưới:
    // this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
// Tạo đối tượng form KhoaHoc
    KhoaHoc khoaHocForm = new KhoaHoc();
    
    // Hiển thị form KhoaHoc
    khoaHocForm.setVisible(true);
    
    // Nếu muốn đóng form hiện tại, uncomment dòng dưới:
    // this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
// Tạo instance của form MonHoc
    MonHoc monHocForm = new MonHoc();
    
    // Hiển thị form MonHoc
    monHocForm.setVisible(true);
    
    // Nếu bạn muốn đóng form hiện tại sau khi chuyển sang form MonHoc, bỏ comment dòng dưới:
    // this.dispose();
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ThemActionPerformed
 // Lấy dữ liệu từ các control
    String maKhoaHoc = (String) jComboBox1MaKH.getSelectedItem();
    String tenCN = (String) jComboBox2TenCN.getSelectedItem();
    String tenMon = (String) jComboBox3TenMH.getSelectedItem();
    String maNHKK = (String) jComboBox4MaNH.getSelectedItem();
    String batBuocStr = (String) jComboBox5BatBuoc.getSelectedItem();
    
    // Kiểm tra các trường rỗng
    if (maKhoaHoc.startsWith("--") || tenCN.startsWith("--") || tenMon.startsWith("--") || maNHKK.startsWith("--") || batBuocStr.startsWith("--")) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn đầy đủ thông tin!");
        return;
    }

    // Chuyển đổi tên chuyên ngành & tên môn sang mã
    String maCN = getMaCNByTen(tenCN);
    String maMon = getMaMonByTen(tenMon);
    boolean batBuoc = batBuocStr.equals("✔ Bắt buộc");
    
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        String sql = "INSERT INTO ChuongTrinhDaoTao (MaKhoaHoc, MaCN, MaMon, MaNHKK, BatBuoc) VALUES (?,?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, maKhoaHoc);
        pst.setString(2, maCN);
        pst.setString(3, maMon);
        pst.setString(4, maNHKK);
        pst.setBoolean(5, batBuoc);
        
        int rowsInserted = pst.executeUpdate();
        JOptionPane.showMessageDialog(this, rowsInserted > 0 ? "Thêm chương trình đào tạo thành công!" : "Thêm thất bại.");
        loadDataToTableChuongTrinhDaoTao();
        
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi thêm: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ThemActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
String maCCDT = jTextPane1MaCCDT.getText().trim();
    
    if (maCCDT.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập mã chương trình đào tạo để xóa!");
        return;
    }
    
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        String sql = "DELETE FROM ChuongTrinhDaoTao WHERE MaCTDT = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, Integer.parseInt(maCCDT));
        
        int rowsDeleted = pst.executeUpdate();
        JOptionPane.showMessageDialog(this, rowsDeleted > 0 ? "Xóa chương trình đào tạo thành công!" : "Không tìm thấy chương trình đào tạo cần xóa.");
        loadDataToTableChuongTrinhDaoTao();
        
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi xóa: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton4SuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4SuaActionPerformed
String maCCDT = jTextPane1MaCCDT.getText().trim();
    String maKhoaHoc = (String) jComboBox1MaKH.getSelectedItem();
    String tenCN = (String) jComboBox2TenCN.getSelectedItem();
    String tenMon = (String) jComboBox3TenMH.getSelectedItem();
    String maNHKK = (String) jComboBox4MaNH.getSelectedItem();
    String batBuocStr = (String) jComboBox5BatBuoc.getSelectedItem();

    if (maCCDT.isEmpty() || maKhoaHoc.startsWith("--") || tenCN.startsWith("--") || tenMon.startsWith("--") || maNHKK.startsWith("--") || batBuocStr.startsWith("--")) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập mã chương trình đào tạo và chọn đầy đủ thông tin!");
        return;
    }

    String maCN = getMaCNByTen(tenCN);
    String maMon = getMaMonByTen(tenMon);
    boolean batBuoc = batBuocStr.equals("✔ Bắt buộc");

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        String sql = "UPDATE ChuongTrinhDaoTao SET MaKhoaHoc = ?, MaCN = ?, MaMon = ?, MaNHKK = ?, BatBuoc = ? WHERE MaCTDT = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, maKhoaHoc);
        pst.setString(2, maCN);
        pst.setString(3, maMon);
        pst.setString(4, maNHKK);
        pst.setBoolean(5, batBuoc);
        pst.setInt(6, Integer.parseInt(maCCDT));
        
        int rowsUpdated = pst.executeUpdate();
        JOptionPane.showMessageDialog(this, rowsUpdated > 0 ? "Cập nhật chương trình đào tạo thành công!" : "Không tìm thấy chương trình đào tạo để cập nhật.");
        loadDataToTableChuongTrinhDaoTao();
        
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi cập nhật: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4SuaActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
loadDataToTableChuongTrinhDaoTao();loadCCDT();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton12ActionPerformed

    private void HienTHiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HienTHiActionPerformed
// Lấy chỉ số dòng đang được chọn trong bảng jTable2
    int selectedRow = jTable2.getSelectedRow();

    // Nếu chưa chọn dòng nào thì thông báo cho người dùng
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một chương trình đào tạo từ bảng!");
        return;
    }

    // Lấy model của jTable2
    DefaultTableModel model = (DefaultTableModel) jTable2.getModel();

    // Lấy dữ liệu từ các cột theo thứ tự
    String maCCDT  = model.getValueAt(selectedRow, 0).toString();
    String maKhoaHoc = model.getValueAt(selectedRow, 1).toString();
    String tenCN = model.getValueAt(selectedRow, 2).toString();
    String tenMon = model.getValueAt(selectedRow, 3).toString();
    String maNHKK = model.getValueAt(selectedRow, 4).toString();
    String batBuocStr = model.getValueAt(selectedRow, 5).toString();

    // Hiển thị thông tin lên các control tương ứng
    jTextPane1MaCCDT.setText(maCCDT);
    jComboBox1MaKH.setSelectedItem(maKhoaHoc);
    jComboBox2TenCN.setSelectedItem(tenCN);
    jComboBox3TenMH.setSelectedItem(tenMon);
    jComboBox4MaNH.setSelectedItem(maNHKK);
    
    // Đặt trạng thái bắt buộc vào jComboBox5BatBuoc
    if (batBuocStr.equals("✔")) {
        jComboBox5BatBuoc.setSelectedItem("✔ Bắt buộc");
    } else {
        jComboBox5BatBuoc.setSelectedItem("✘ Không bắt buộc");
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_HienTHiActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
// Lấy giá trị tìm kiếm từ các control
    String searchMaCCDT = jTextPane1MaCCDT.getText().trim();
    String searchMaKhoaHoc = (String) jComboBox1MaKH.getSelectedItem();
    String searchTenCN = (String) jComboBox2TenCN.getSelectedItem();
    String searchTenMon = (String) jComboBox3TenMH.getSelectedItem();
    String searchMaNHKK = (String) jComboBox4MaNH.getSelectedItem();
    String searchBatBuocStr = (String) jComboBox5BatBuoc.getSelectedItem();
    
    // Kết nối đến CSDL
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        PreparedStatement pst;
        String sql;
        
        // Nếu người dùng nhập Mã CCDT, ưu tiên tìm theo đó
        if (!searchMaCCDT.isEmpty()) {
            sql = "SELECT CTDT.MaCTDT, CTDT.MaKhoaHoc, CN.TenCN, MH.TenMon, CTDT.MaNHKK, CTDT.BatBuoc " +
                  "FROM ChuongTrinhDaoTao CTDT " +
                  "JOIN ChuyenNganh CN ON CTDT.MaCN = CN.MaCN " +
                  "JOIN MonHoc MH ON CTDT.MaMon = MH.MaMon " +
                  "WHERE CTDT.MaCTDT LIKE ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, "%" + searchMaCCDT + "%");
        } else {
            // Nếu Mã CCDT để trống, tìm kiếm theo bộ lọc
            sql = "SELECT CTDT.MaCTDT, CTDT.MaKhoaHoc, CN.TenCN, MH.TenMon, CTDT.MaNHKK, CTDT.BatBuoc " +
                  "FROM ChuongTrinhDaoTao CTDT " +
                  "JOIN ChuyenNganh CN ON CTDT.MaCN = CN.MaCN " +
                  "JOIN MonHoc MH ON CTDT.MaMon = MH.MaMon " +
                  "WHERE 1=1";
            
            java.util.List<Object> params = new java.util.ArrayList<>();
            
            // Nếu chọn Mã khóa học
            if (searchMaKhoaHoc != null && !searchMaKhoaHoc.startsWith("--")) {
                sql += " AND CTDT.MaKhoaHoc = ?";
                params.add(searchMaKhoaHoc);
            }
            // Nếu chọn Tên chuyên ngành
            if (searchTenCN != null && !searchTenCN.startsWith("--")) {
                sql += " AND CN.TenCN LIKE ?";
                params.add("%" + searchTenCN + "%");
            }
            // Nếu chọn Tên môn học
            if (searchTenMon != null && !searchTenMon.startsWith("--")) {
                sql += " AND MH.TenMon LIKE ?";
                params.add("%" + searchTenMon + "%");
            }
            // Nếu chọn Mã năm học
            if (searchMaNHKK != null && !searchMaNHKK.startsWith("--")) {
                sql += " AND CTDT.MaNHKK = ?";
                params.add(searchMaNHKK);
            }
            // Nếu chọn Trạng thái bắt buộc
            if (searchBatBuocStr != null && !searchBatBuocStr.startsWith("--")) {
                boolean batBuoc = searchBatBuocStr.equals("✔ Bắt buộc");
                sql += " AND CTDT.BatBuoc = ?";
                params.add(batBuoc);
            }
            
            pst = conn.prepareStatement(sql);
            for (int i = 0; i < params.size(); i++) {
                pst.setObject(i + 1, params.get(i));
            }
        }
        
        // Thực hiện truy vấn
        ResultSet rs = pst.executeQuery();
        
        // Lấy model của jTable2 và xoá dữ liệu cũ
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);
        
        // Duyệt qua kết quả truy vấn và đưa dữ liệu vào bảng
        while (rs.next()) {
            Object[] row = {
                rs.getInt("MaCTDT"),
                rs.getString("MaKhoaHoc"),
                rs.getString("TenCN"),
                rs.getString("TenMon"),
                rs.getString("MaNHKK"),
                rs.getBoolean("BatBuoc") ? "✔ Bắt buộc" : "✘ Không bắt buộc"
            };
            model.addRow(row);
        }
        
        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tìm kiếm chương trình đào tạo: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton14ActionPerformed
private byte[] getAnhTuJLabel(JLabel label) {
    Icon icon = label.getIcon();
    if (icon instanceof ImageIcon) {
        Image img = ((ImageIcon) icon).getImage();
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedImage bufferedImage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = bufferedImage.createGraphics();
            g2d.drawImage(img, 0, 0, null);
            g2d.dispose();

            ImageIO.write(bufferedImage, "jpg", baos);
            return baos.toByteArray();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Lỗi khi chuyển ảnh thành dữ liệu: " + e.getMessage());
        }
    }
    return null;
}
    private void ChonAnhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChonAnhActionPerformed
JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Chọn ảnh giảng viên");
    fileChooser.setFileFilter(new FileNameExtensionFilter("Hình ảnh", "jpg", "jpeg", "png"));

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {
        File selectedFile = fileChooser.getSelectedFile();
        try {
            // Đọc dữ liệu ảnh và hiển thị lên `jLabelHienThiAnhGV`
            ImageIcon imageIcon = new ImageIcon(selectedFile.getAbsolutePath());
            Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            HienThiAnhGV.setIcon(new ImageIcon(image));

            // Chuyển ảnh thành mảng byte để lưu vào CSDL
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedImage bufferedImage = ImageIO.read(selectedFile);
            ImageIO.write(bufferedImage, "jpg", baos);
            byte[] imageData = baos.toByteArray();

            // Lưu ảnh vào CSDL (chỉnh sửa bảng GiangVien để cập nhật ảnh)
            String maGV =  MaGV.getText().trim();
            if (!maGV.isEmpty()) {
                saveImageToDatabase(maGV, imageData);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi tải ảnh: " + e.getMessage());
        }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_ChonAnhActionPerformed
private void saveImageToDatabase(String maGV, byte[] imageData) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "UPDATE GiangVien SET Anh = ? WHERE MaGV = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setBytes(1, imageData);
        pst.setString(2, maGV);

        int rowsUpdated = pst.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Ảnh giảng viên đã được cập nhật!");
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy giảng viên để lưu ảnh.");
        }

        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi cập nhật ảnh giảng viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
}
    private void HienThiGVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HienThiGVActionPerformed
// Lấy chỉ số dòng đang được chọn trong bảng jTable1GiangVien
    int selectedRow = jTable1GiangVien.getSelectedRow();

    // Nếu chưa chọn dòng nào thì thông báo cho người dùng
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một giảng viên từ bảng!");
        return;
    }

    // Lấy model của jTable1GiangVien
    DefaultTableModel model = (DefaultTableModel) jTable1GiangVien.getModel();

    // Lấy dữ liệu từ các cột theo thứ tự
    String maGV  = model.getValueAt(selectedRow, 0).toString();
    String tenGV = model.getValueAt(selectedRow, 1).toString();
    String ngaySinh = model.getValueAt(selectedRow, 2).toString();
    String tenKhoa = model.getValueAt(selectedRow, 3).toString();
    String tenMon = model.getValueAt(selectedRow, 4).toString();
    String gioiTinh = model.getValueAt(selectedRow, 5).toString();
    String email = model.getValueAt(selectedRow, 6).toString();
    String sdt = model.getValueAt(selectedRow, 7).toString();
    String diaChi = model.getValueAt(selectedRow, 8).toString();
    String ngayVaoLam = model.getValueAt(selectedRow, 9).toString();
    String trinhDo = model.getValueAt(selectedRow, 10).toString();
    String chucVu = model.getValueAt(selectedRow, 11).toString();
    String cccd = model.getValueAt(selectedRow, 12).toString();
    String ghiChu = model.getValueAt(selectedRow, 13).toString();
    String taiKhoan = model.getValueAt(selectedRow, 14).toString();
    String matKhau = model.getValueAt(selectedRow, 15).toString();

    // Hiển thị thông tin lên các control tương ứng
    MaGV.setText(maGV);
    TenGV.setText(tenGV);
    NgaySinh.setText(ngaySinh);
    jComboBox1Khoa.setSelectedItem(tenKhoa);
    jComboBox2MonHoc.setSelectedItem(tenMon);
    jComboBox3GioiTinh.setSelectedItem(gioiTinh);
    Email.setText(email);
    SDT.setText(sdt);
    DiaChi.setText(diaChi);
    NgayVaoLam.setText(ngayVaoLam);
    TrinHDo.setText(trinhDo);
    ChuCVU.setText(chucVu);
    CCCD.setText(cccd);
    GhiCHus.setText(ghiChu);
    TaiKhoan.setText(taiKhoan);
    MatKhau.setText(matKhau);

    // Hiển thị ảnh giảng viên (giả sử ảnh được lưu dưới dạng byte[])
    try {
        Object imageDataObj = model.getValueAt(selectedRow, 16); // Cột 16 chứa ảnh
        
        if (imageDataObj != null && imageDataObj instanceof byte[]) {
            byte[] imageData = (byte[]) imageDataObj;
            if (imageData.length > 0) {
                ImageIcon imageIcon = new ImageIcon(imageData);
                Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                HienThiAnhGV.setIcon(new ImageIcon(image));
            } else {
                HienThiAnhGV.setIcon(null); // Nếu ảnh rỗng, xóa ảnh hiển thị
            }
        } else {
            HienThiAnhGV.setIcon(null); // Nếu không có ảnh, xóa ảnh hiển thị
        }
    } catch (Exception e) {
        HienThiAnhGV.setIcon(null);
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi hiển thị ảnh: " + e.getMessage());
    }

    }//GEN-LAST:event_HienThiGVActionPerformed
private String getMaKhoaByTen(String tenKhoa) {
    String maKhoa = null;
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return null;
    }

    try {
        String sql = "SELECT MaKhoa FROM Khoa WHERE TenKhoa = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenKhoa);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            maKhoa = rs.getString("MaKhoa");
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi lấy mã khoa: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }

    return maKhoa;
}
    private void ThemGVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemGVActionPerformed
// Lấy dữ liệu từ các control
    String maGV =  MaGV.getText().trim();
    String tenGV =  TenGV.getText().trim();
    String ngaySinh =  NgaySinh.getText().trim();
    String tenKhoa = (String) jComboBox1Khoa.getSelectedItem();
    String tenMon = (String) jComboBox2MonHoc.getSelectedItem();
    String gioiTinh = (String) jComboBox3GioiTinh.getSelectedItem();
    String email =  Email.getText().trim();
    String sdt =  SDT.getText().trim();
    String diaChi =  DiaChi.getText().trim();
    String ngayVaoLam =  NgayVaoLam.getText().trim();
    String trinhDo = TrinHDo.getText().trim();
    String chucVu = ChuCVU.getText().trim();
    String cccd = CCCD.getText().trim();
    String ghiChu = GhiCHus.getText().trim();
    String taiKhoan = TaiKhoan.getText().trim();
    String matKhau = MatKhau.getText().trim();
    
    // Kiểm tra nhập rỗng
    if (maGV.isEmpty() || tenGV.isEmpty() || ngaySinh.isEmpty() || ngayVaoLam.isEmpty() || email.isEmpty() || sdt.isEmpty() || taiKhoan.isEmpty() || matKhau.isEmpty()) {
        JOptionPane.showMessageDialog(this, "❌ Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    // Định dạng ngày hợp lệ
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);

    try {
        java.sql.Date ngaySinhSQL = new java.sql.Date(sdf.parse(ngaySinh).getTime());
        java.sql.Date ngayVaoLamSQL = new java.sql.Date(sdf.parse(ngayVaoLam).getTime());

        // Xử lý ảnh
        byte[] imgData = getAnhTuJLabel(HienThiAnhGV);

        Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
        PreparedStatement pst = conn.prepareStatement("INSERT INTO GiangVien (MaGV, HoTen, NgaySinh, MaKhoa, BoMon, GioiTinh, Email, SDT, DiaChi, NgayVaoLam, TrinhDo, ChucVu, CCCD, GhiChu, Anh) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

        pst.setString(1, maGV);
        pst.setString(2, tenGV);
        pst.setDate(3, ngaySinhSQL);
        pst.setString(4, getMaKhoaByTen(tenKhoa));
        pst.setString(5, tenMon);
        pst.setString(6, gioiTinh);
        pst.setString(7, email);
        pst.setString(8, sdt);
        pst.setString(9, diaChi);
        pst.setDate(10, ngayVaoLamSQL);
        pst.setString(11, trinhDo);
        pst.setString(12, chucVu);
        pst.setString(13, cccd);
        pst.setString(14, ghiChu);
        if (imgData != null) {
            pst.setBytes(15, imgData);
        } else {
            pst.setNull(15, java.sql.Types.BLOB);
        }

        pst.executeUpdate();

        // Thêm tài khoản giảng viên vào bảng TaiKhoan
        PreparedStatement pstTK = conn.prepareStatement("INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, MaLienKet) VALUES (?,?,?,?)");
        pstTK.setString(1, taiKhoan);
        pstTK.setString(2, matKhau);
        pstTK.setString(3, "giangvien");
        pstTK.setString(4, maGV);
        pstTK.executeUpdate();

        JOptionPane.showMessageDialog(this, "✔ Thêm giảng viên thành công!");
        loadDataToTableGiangVien();

        pst.close();
        pstTK.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi thêm giảng viên: " + e.getMessage());
    }

    }//GEN-LAST:event_ThemGVActionPerformed

    private void XoaGVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XoaGVActionPerformed
String maGV = MaGV.getText().trim();

    if (maGV.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập mã giảng viên để xóa!");
        return;
    }

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        // Xóa tài khoản của giảng viên trước
        String sqlTK = "DELETE FROM TaiKhoan WHERE MaLienKet = ?";
        PreparedStatement pstTK = conn.prepareStatement(sqlTK);
        pstTK.setString(1, maGV);
        pstTK.executeUpdate();

        // Xóa giảng viên trong bảng GiangVien
        String sqlGV = "DELETE FROM GiangVien WHERE MaGV = ?";
        PreparedStatement pstGV = conn.prepareStatement(sqlGV);
        pstGV.setString(1, maGV);
        int rowsDeleted = pstGV.executeUpdate();

        JOptionPane.showMessageDialog(this, rowsDeleted > 0 ? "Xóa giảng viên thành công!" : "Không tìm thấy giảng viên cần xóa.");
        loadDataToTableGiangVien();

        pstGV.close();
        pstTK.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi xóa giảng viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_XoaGVActionPerformed

    private void SuaGVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuaGVActionPerformed
    String maGV =  MaGV.getText().trim();
    String tenGV =  TenGV.getText().trim();
    String ngaySinh =  NgaySinh.getText().trim();
    String tenKhoa = (String) jComboBox1Khoa.getSelectedItem();
    String tenMon = (String) jComboBox2MonHoc.getSelectedItem();
    String gioiTinh = (String) jComboBox3GioiTinh.getSelectedItem();
    String email =  Email.getText().trim();
    String sdt =  SDT.getText().trim();
    String diaChi =  DiaChi.getText().trim();
    String ngayVaoLam =  NgayVaoLam.getText().trim();
    String trinhDo = TrinHDo.getText().trim();
    String chucVu = ChuCVU.getText().trim();
    String cccd = CCCD.getText().trim();
    String ghiChu = GhiCHus.getText().trim();
    String taiKhoan = TaiKhoan.getText().trim();
    String matKhau = MatKhau.getText().trim();
    
    if (maGV.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập mã giảng viên để sửa!");
        return;
    }

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "UPDATE GiangVien SET HoTen=?, NgaySinh=?, MaKhoa=?, BoMon=?, GioiTinh=?, Email=?, SDT=?, DiaChi=?, NgayVaoLam=?, TrinhDo=?, ChucVu=?, CCCD=?, GhiChu=? WHERE MaGV=?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenGV);
        pst.setDate(2, java.sql.Date.valueOf(ngaySinh));
        pst.setString(3, getMaKhoaByTen(tenKhoa));
        pst.setString(4, tenMon);
        pst.setString(5, gioiTinh);
        pst.setString(6, email);
        pst.setString(7, sdt);
        pst.setString(8, diaChi);
        pst.setDate(9, java.sql.Date.valueOf(ngayVaoLam));
        pst.setString(10, trinhDo);
        pst.setString(11, chucVu);
        pst.setString(12, cccd);
        pst.setString(13, ghiChu);
        pst.setString(14, maGV);

        int rowsUpdated = pst.executeUpdate();
        JOptionPane.showMessageDialog(this, rowsUpdated > 0 ? "Cập nhật giảng viên thành công!" : "Không tìm thấy giảng viên để sửa.");
        loadDataToTableGiangVien();

        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi cập nhật giảng viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_SuaGVActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
    // Reset tất cả các JTextField
    MaGV.setText("");
    TenGV.setText("");
    NgaySinh.setText("");
    Email.setText("");
    SDT.setText("");
    DiaChi.setText("");
    NgayVaoLam.setText("");
    TrinHDo.setText("");
    ChuCVU.setText("");
    CCCD.setText("");
    GhiCHus.setText("");
    TaiKhoan.setText("");
    MatKhau.setText("");

    // Reset tất cả các JComboBox về mặc định
    jComboBox1Khoa.setSelectedIndex(0);
    jComboBox2MonHoc.setSelectedIndex(0);
    jComboBox3GioiTinh.setSelectedIndex(0);

    // Reset ảnh hiển thị về mặc định (hoặc xóa ảnh)
    HienThiAnhGV.setIcon(null);

        loadDataToTableGiangVien();        // TODO add your handling code here:
    }//GEN-LAST:event_resetActionPerformed

    private void TImKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TImKiemActionPerformed
// Lấy giá trị tìm kiếm từ các control
String searchMaGV = MaGV.getText().trim();
String searchTenGV = TenGV.getText().trim();
String searchNgaySinh = NgaySinh.getText().trim();
String searchTenKhoa = (String) jComboBox1Khoa.getSelectedItem();
String searchTenMon = (String) jComboBox2MonHoc.getSelectedItem();
String searchGioiTinh = (String) jComboBox3GioiTinh.getSelectedItem();
String searchEmail = Email.getText().trim();
String searchSDT = SDT.getText().trim();
String searchDiaChi = DiaChi.getText().trim();
String searchNgayVaoLam = NgayVaoLam.getText().trim();
String searchTrinhDo = TrinHDo.getText().trim();
String searchChucVu = ChuCVU.getText().trim();
String searchCCCD = CCCD.getText().trim();
String searchGhiChu = GhiCHus.getText().trim();
String searchTaiKhoan = TaiKhoan.getText().trim();
String searchMatKhau = MatKhau.getText().trim();

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        PreparedStatement pst;
        String sql = "SELECT GV.MaGV, GV.HoTen, GV.NgaySinh, K.TenKhoa, GV.BoMon, GV.GioiTinh, GV.Email, GV.SDT, " +
                     "GV.DiaChi, GV.NgayVaoLam, GV.TrinhDo, GV.ChucVu, GV.CCCD, GV.GhiChu, TK.TenDangNhap, TK.MatKhau, GV.Anh " +
                     "FROM GiangVien GV " +
                     "JOIN Khoa K ON GV.MaKhoa = K.MaKhoa " +
                     "LEFT JOIN TaiKhoan TK ON GV.MaGV = TK.MaLienKet " +
                     "WHERE 1=1"; // Điều kiện luôn đúng để tiện bổ sung AND

        java.util.List<Object> params = new java.util.ArrayList<>();

        // Nếu nhập Mã GV, tìm theo đó
        if (!searchMaGV.isEmpty()) {
            sql += " AND GV.MaGV LIKE ?";
            params.add("%" + searchMaGV + "%");
        }
        // Nếu nhập Họ tên
        if (!searchTenGV.isEmpty()) {
            sql += " AND GV.HoTen LIKE ?";
            params.add("%" + searchTenGV + "%");
        }
        // Nếu chọn Tên khoa
        if (searchTenKhoa != null && !searchTenKhoa.startsWith("--")) {
            sql += " AND K.TenKhoa = ?";
            params.add(searchTenKhoa);
        }
        // Nếu chọn Bộ môn
        if (searchTenMon != null && !searchTenMon.startsWith("--")) {
            sql += " AND GV.BoMon LIKE ?";
            params.add("%" + searchTenMon + "%");
        }
        // Nếu chọn Giới tính
        if (searchGioiTinh != null && !searchGioiTinh.startsWith("--")) {
            sql += " AND GV.GioiTinh = ?";
            params.add(searchGioiTinh);
        }
        // Nếu nhập Email
        if (!searchEmail.isEmpty()) {
            sql += " AND GV.Email LIKE ?";
            params.add("%" + searchEmail + "%");
        }
        // Nếu nhập SĐT
        if (!searchSDT.isEmpty()) {
            sql += " AND GV.SDT LIKE ?";
            params.add("%" + searchSDT + "%");
        }
        // Nếu nhập Địa chỉ
        if (!searchDiaChi.isEmpty()) {
            sql += " AND GV.DiaChi LIKE ?";
            params.add("%" + searchDiaChi + "%");
        }
        // Nếu nhập Ngày vào làm
        if (!searchNgayVaoLam.isEmpty()) {
            sql += " AND GV.NgayVaoLam = ?";
            params.add(java.sql.Date.valueOf(searchNgayVaoLam));
        }
        // Nếu nhập Trình độ
        if (!searchTrinhDo.isEmpty()) {
            sql += " AND GV.TrinhDo LIKE ?";
            params.add("%" + searchTrinhDo + "%");
        }
        // Nếu nhập Chức vụ
        if (!searchChucVu.isEmpty()) {
            sql += " AND GV.ChucVu LIKE ?";
            params.add("%" + searchChucVu + "%");
        }
        // Nếu nhập CCCD
        if (!searchCCCD.isEmpty()) {
            sql += " AND GV.CCCD LIKE ?";
            params.add("%" + searchCCCD + "%");
        }
        // Nếu nhập Ghi chú
        if (!searchGhiChu.isEmpty()) {
            sql += " AND GV.GhiChu LIKE ?";
            params.add("%" + searchGhiChu + "%");
        }
        // Nếu nhập Tài khoản
        if (!searchTaiKhoan.isEmpty()) {
            sql += " AND TK.TenDangNhap LIKE ?";
            params.add("%" + searchTaiKhoan + "%");
        }

        pst = conn.prepareStatement(sql);
        for (int i = 0; i < params.size(); i++) {
            pst.setObject(i + 1, params.get(i));
        }

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) jTable1GiangVien.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            Object[] row = {
                rs.getString("MaGV"),
                rs.getString("HoTen"),
                rs.getDate("NgaySinh"),
                rs.getString("TenKhoa"),
                rs.getString("BoMon"),
                rs.getString("GioiTinh"),
                rs.getString("Email"),
                rs.getString("SDT"),
                rs.getString("DiaChi"),
                rs.getDate("NgayVaoLam"),
                rs.getString("TrinhDo"),
                rs.getString("ChucVu"),
                rs.getString("CCCD"),
                rs.getString("GhiChu"),
                rs.getString("TenDangNhap"),
                rs.getString("MatKhau"),
                rs.getBytes("Anh") // Lấy dữ liệu ảnh dưới dạng byte[]
            };
            model.addRow(row);
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tìm kiếm giảng viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_TImKiemActionPerformed

    private void ThemSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ThemSVActionPerformed
// Lấy dữ liệu từ các control
    String maSV = MSV.getText().trim();
    String hoTen = HoTen.getText().trim();
    String ngaySinh = NgaySinhSV.getText().trim();
    String gioiTinh = (String) jComboBox4GioiTInh.getSelectedItem();
    String email = emailSV.getText().trim();
    String sdt = SDTSV.getText().trim();
    String diaChi = DiaChiSV.getText().trim();
    String ngayNhapHoc = NgayNhapHoc.getText().trim();
    String trangThai = (String) jComboBox6TrangTHai.getSelectedItem();
    String cccd = CCCDSV.getText().trim();
    String ghiChu = GhiChuSV.getText().trim();
    String lop = (String) jComboBox5Lop.getSelectedItem();
    String taiKhoan = TaiKhoanSV.getText().trim();
    String matKhau = MatKhauSV.getText().trim();

    // Kiểm tra nhập rỗng
    if (maSV.isEmpty() || hoTen.isEmpty() || ngaySinh.isEmpty() || ngayNhapHoc.isEmpty() ||
        gioiTinh.startsWith("--") || email.isEmpty() || sdt.isEmpty() || lop.startsWith("--") ||
        taiKhoan.isEmpty() || matKhau.isEmpty()) {
        JOptionPane.showMessageDialog(this, "❌ Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    // Định dạng ngày hợp lệ
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    sdf.setLenient(false);

    try {
        java.sql.Date ngaySinhSQL = new java.sql.Date(sdf.parse(ngaySinh).getTime());
        java.sql.Date ngayNhapHocSQL = new java.sql.Date(sdf.parse(ngayNhapHoc).getTime());

        // Xử lý ảnh
        byte[] imgData = getAnhTuJLabel(HienThiAnhSV);

        Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
        PreparedStatement pst = conn.prepareStatement("INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, Email, SDT, DiaChi, NgayVaoHoc, TrangThai, CCCD, GhiChu, MaLop, Anh) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");

        pst.setString(1, maSV);
        pst.setString(2, hoTen);
        pst.setDate(3, ngaySinhSQL);
        pst.setString(4, gioiTinh);
        pst.setString(5, email);
        pst.setString(6, sdt);
        pst.setString(7, diaChi);
        pst.setDate(8, ngayNhapHocSQL);
        pst.setString(9, trangThai);
        pst.setString(10, cccd);
        pst.setString(11, ghiChu);
        pst.setString(12, getMaLopByTen(lop));
        pst.setBytes(13, imgData != null ? imgData : null);

        pst.executeUpdate();

        // Thêm tài khoản sinh viên vào bảng TaiKhoan
        PreparedStatement pstTK = conn.prepareStatement("INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, MaLienKet) VALUES (?,?,?,?)");
        pstTK.setString(1, taiKhoan);
        pstTK.setString(2, matKhau);
        pstTK.setString(3, "sinhvien");
        pstTK.setString(4, maSV);
        pstTK.executeUpdate();

        JOptionPane.showMessageDialog(this, "✔ Thêm sinh viên thành công!");
        loadDataToTableSinhVien();

        pst.close();
        pstTK.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi thêm sinh viên: " + e.getMessage());
    }

    }//GEN-LAST:event_ThemSVActionPerformed

    private void HienThiSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HienThiSVActionPerformed
// Lấy chỉ số dòng đang được chọn trong bảng jTable3SinhVien
    int selectedRow = jTable3SinhVien.getSelectedRow();

    // Nếu chưa chọn dòng nào thì thông báo cho người dùng
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một sinh viên từ bảng!");
        return;
    }

    // Lấy model của jTable3SinhVien
    DefaultTableModel model = (DefaultTableModel) jTable3SinhVien.getModel();

    // Lấy dữ liệu từ các cột theo thứ tự
    String maSV  = model.getValueAt(selectedRow, 0).toString();
    String hoTen = model.getValueAt(selectedRow, 1).toString();
    String ngaySinh = model.getValueAt(selectedRow, 2).toString();
    String gioiTinh = model.getValueAt(selectedRow, 3).toString();
    String email = model.getValueAt(selectedRow, 4).toString();
    String sdt = model.getValueAt(selectedRow, 5).toString();
    String diaChi = model.getValueAt(selectedRow, 6).toString();
    String ngayNhapHoc = model.getValueAt(selectedRow, 7).toString();
    String trangThai = model.getValueAt(selectedRow, 8).toString();
    String cccd = model.getValueAt(selectedRow, 9).toString();
    String ghiChu = model.getValueAt(selectedRow, 10).toString();
    String tenLop = model.getValueAt(selectedRow, 11).toString();

    // Hiển thị thông tin lên các control tương ứng
    MSV.setText(maSV);
    HoTen.setText(hoTen);
    NgaySinhSV.setText(ngaySinh);
    jComboBox4GioiTInh.setSelectedItem(gioiTinh);
    emailSV.setText(email);
    SDTSV.setText(sdt);
    DiaChiSV.setText(diaChi);
    NgayNhapHoc.setText(ngayNhapHoc);
    jComboBox6TrangTHai.setSelectedItem(trangThai);
    CCCDSV.setText(cccd);
    GhiChuSV.setText(ghiChu);
    jComboBox5Lop.setSelectedItem(tenLop);

    // Hiển thị ảnh sinh viên (giả sử ảnh được lưu dưới dạng byte[])
    try {
        Object imageDataObj = model.getValueAt(selectedRow, 12); // Cột 12 chứa ảnh
        
        if (imageDataObj != null && imageDataObj instanceof byte[]) {
            byte[] imageData = (byte[]) imageDataObj;
            if (imageData.length > 0) {
                ImageIcon imageIcon = new ImageIcon(imageData);
                Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                HienThiAnhSV.setIcon(new ImageIcon(image));
            } else {
                HienThiAnhSV.setIcon(null); // Nếu ảnh rỗng, xóa ảnh hiển thị
            }
        } else {
            HienThiAnhSV.setIcon(null); // Nếu không có ảnh, xóa ảnh hiển thị
        }
    } catch (Exception e) {
        HienThiAnhSV.setIcon(null);
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi hiển thị ảnh: " + e.getMessage());
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_HienThiSVActionPerformed

    private void SuaSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SuaSVActionPerformed
String maSV = MSV.getText().trim();
    if (maSV.isEmpty()) {
        JOptionPane.showMessageDialog(this, "❌ Vui lòng nhập mã sinh viên để sửa!");
        return;
    }

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "UPDATE SinhVien SET HoTen=?, NgaySinh=?, GioiTinh=?, Email=?, SDT=?, DiaChi=?, NgayVaoHoc=?, TrangThai=?, CCCD=?, GhiChu=?, MaLop=?, Anh=? WHERE MaSV=?";
        PreparedStatement pst = conn.prepareStatement(sql);

        pst.setString(1, HoTen.getText().trim());
        pst.setDate(2, new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(NgaySinhSV.getText().trim()).getTime()));
        pst.setString(3, (String) jComboBox4GioiTInh.getSelectedItem());
        pst.setString(4, emailSV.getText().trim());
        pst.setString(5, SDTSV.getText().trim());
        pst.setString(6, DiaChiSV.getText().trim());
        pst.setDate(7, new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse(NgayNhapHoc.getText().trim()).getTime()));
        pst.setString(8, (String) jComboBox6TrangTHai.getSelectedItem());
        pst.setString(9, CCCDSV.getText().trim());
        pst.setString(10, GhiChuSV.getText().trim());
        pst.setString(11, getMaLopByTen((String) jComboBox5Lop.getSelectedItem()));
        pst.setBytes(12, getAnhTuJLabel(HienThiAnhSV));
        pst.setString(13, maSV);

        pst.executeUpdate();
        JOptionPane.showMessageDialog(this, "✔ Cập nhật sinh viên thành công!");
        loadDataToTableSinhVien();

        pst.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi cập nhật sinh viên: " + e.getMessage());
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_SuaSVActionPerformed

    private void XoaSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_XoaSVActionPerformed
String maSV = MSV.getText().trim();

    if (maSV.isEmpty()) {
        JOptionPane.showMessageDialog(this, "❌ Vui lòng nhập mã sinh viên để xóa!");
        return;
    }

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        PreparedStatement pstTK = conn.prepareStatement("DELETE FROM TaiKhoan WHERE MaLienKet = ?");
        pstTK.setString(1, maSV);
        pstTK.executeUpdate();

        PreparedStatement pstSV = conn.prepareStatement("DELETE FROM SinhVien WHERE MaSV = ?");
        pstSV.setString(1, maSV);
        int rowsDeleted = pstSV.executeUpdate();

        JOptionPane.showMessageDialog(this, rowsDeleted > 0 ? "✔ Xóa sinh viên thành công!" : "❌ Không tìm thấy sinh viên để xóa.");
        loadDataToTableSinhVien();

        pstSV.close();
        pstTK.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi xóa sinh viên: " + e.getMessage());
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_XoaSVActionPerformed

    private void ChonAnhSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChonAnhSVActionPerformed
JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Chọn ảnh sinh viên");
    fileChooser.setFileFilter(new FileNameExtensionFilter("Hình ảnh", "jpg", "jpeg", "png"));

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {
        File selectedFile = fileChooser.getSelectedFile();
        try {
            // Đọc dữ liệu ảnh và hiển thị lên `HienThiAnhSV`
            ImageIcon imageIcon = new ImageIcon(selectedFile.getAbsolutePath());
            Image image = imageIcon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
            HienThiAnhSV.setIcon(new ImageIcon(image));

            // Chuyển ảnh thành mảng byte để lưu vào CSDL
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            BufferedImage bufferedImage = ImageIO.read(selectedFile);
            ImageIO.write(bufferedImage, "jpg", baos);
            byte[] imageData = baos.toByteArray();

            // Lưu ảnh vào CSDL (nếu có mã sinh viên)
            String maSV = MSV.getText().trim();
            if (!maSV.isEmpty()) {
                saveImageToDatabase(maSV, imageData);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải ảnh: " + e.getMessage());
        }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_ChonAnhSVActionPerformed

    private void ResetSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ResetSVActionPerformed
loadDataToTableSinhVien();// Reset tất cả các JTextField
    MSV.setText("");
    HoTen.setText("");
    NgaySinhSV.setText("");
    emailSV.setText("");
    SDTSV.setText("");
    DiaChiSV.setText("");
    NgayNhapHoc.setText("");
    CCCDSV.setText("");
    GhiChuSV.setText("");
    TaiKhoanSV.setText("");
    MatKhauSV.setText("");

    // Reset tất cả các JComboBox về mặc định
    jComboBox4GioiTInh.setSelectedIndex(0);
    jComboBox6TrangTHai.setSelectedIndex(0);
    jComboBox5Lop.setSelectedIndex(0);

    // Reset ảnh hiển thị về mặc định (hoặc xóa ảnh)
    HienThiAnhSV.setIcon(null);
        // TODO add your handling code here:
    }//GEN-LAST:event_ResetSVActionPerformed

    private void TimKiemSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TimKiemSVActionPerformed
// Lấy giá trị tìm kiếm từ các control
    String searchMaSV = MSV.getText().trim();
    String searchHoTen = HoTen.getText().trim();
    String searchNgaySinh = NgaySinhSV.getText().trim();
    String searchGioiTinh = (String) jComboBox4GioiTInh.getSelectedItem();
    String searchEmail = emailSV.getText().trim();
    String searchSDT = SDTSV.getText().trim();
    String searchDiaChi = DiaChiSV.getText().trim();
    String searchNgayNhapHoc = NgayNhapHoc.getText().trim();
    String searchTrangThai = (String) jComboBox6TrangTHai.getSelectedItem();
    String searchCCCD = CCCDSV.getText().trim();
    String searchGhiChu = GhiChuSV.getText().trim();
    String searchLop = (String) jComboBox5Lop.getSelectedItem();
    String searchTaiKhoan = TaiKhoanSV.getText().trim();

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        PreparedStatement pst;
        String sql = "SELECT SV.MaSV, SV.HoTen, SV.NgaySinh, SV.GioiTinh, SV.Email, SV.SDT, SV.DiaChi, " +
                     "SV.NgayVaoHoc, SV.TrangThai, SV.CCCD, SV.GhiChu, L.TenLop, SV.Anh, TK.TenDangNhap, TK.MatKhau " +
                     "FROM SinhVien SV " +
                     "JOIN Lop L ON SV.MaLop = L.MaLop " +
                     "LEFT JOIN TaiKhoan TK ON SV.MaSV = TK.MaLienKet " +
                     "WHERE 1=1"; // Điều kiện luôn đúng để tiện bổ sung AND

        java.util.List<Object> params = new java.util.ArrayList<>();

        // Nếu nhập Mã SV, tìm theo đó
        if (!searchMaSV.isEmpty()) {
            sql += " AND SV.MaSV LIKE ?";
            params.add("%" + searchMaSV + "%");
        }
        // Nếu nhập Họ tên
        if (!searchHoTen.isEmpty()) {
            sql += " AND SV.HoTen LIKE ?";
            params.add("%" + searchHoTen + "%");
        }
        // Nếu nhập Ngày sinh
        if (!searchNgaySinh.isEmpty()) {
            sql += " AND SV.NgaySinh = ?";
            params.add(java.sql.Date.valueOf(searchNgaySinh));
        }
        // Nếu chọn Giới tính
        if (searchGioiTinh != null && !searchGioiTinh.startsWith("--")) {
            sql += " AND SV.GioiTinh = ?";
            params.add(searchGioiTinh);
        }
        // Nếu nhập Email
        if (!searchEmail.isEmpty()) {
            sql += " AND SV.Email LIKE ?";
            params.add("%" + searchEmail + "%");
        }
        // Nếu nhập SĐT
        if (!searchSDT.isEmpty()) {
            sql += " AND SV.SDT LIKE ?";
            params.add("%" + searchSDT + "%");
        }
        // Nếu nhập Địa chỉ
        if (!searchDiaChi.isEmpty()) {
            sql += " AND SV.DiaChi LIKE ?";
            params.add("%" + searchDiaChi + "%");
        }
        // Nếu nhập Ngày nhập học
        if (!searchNgayNhapHoc.isEmpty()) {
            sql += " AND SV.NgayVaoHoc = ?";
            params.add(java.sql.Date.valueOf(searchNgayNhapHoc));
        }
        // Nếu chọn Trạng thái
        if (searchTrangThai != null && !searchTrangThai.startsWith("--")) {
            sql += " AND SV.TrangThai = ?";
            params.add(searchTrangThai);
        }
        // Nếu nhập CCCD
        if (!searchCCCD.isEmpty()) {
            sql += " AND SV.CCCD LIKE ?";
            params.add("%" + searchCCCD + "%");
        }
        // Nếu nhập Ghi chú
        if (!searchGhiChu.isEmpty()) {
            sql += " AND SV.GhiChu LIKE ?";
            params.add("%" + searchGhiChu + "%");
        }
        // Nếu chọn Lớp
        if (searchLop != null && !searchLop.startsWith("--")) {
            sql += " AND L.TenLop = ?";
            params.add(searchLop);
        }
        // Nếu nhập Tài khoản
        if (!searchTaiKhoan.isEmpty()) {
            sql += " AND TK.TenDangNhap LIKE ?";
            params.add("%" + searchTaiKhoan + "%");
        }

        pst = conn.prepareStatement(sql);
        for (int i = 0; i < params.size(); i++) {
            pst.setObject(i + 1, params.get(i));
        }

        ResultSet rs = pst.executeQuery();

        DefaultTableModel model = (DefaultTableModel) jTable3SinhVien.getModel();
        model.setRowCount(0);

        while (rs.next()) {
            Object[] row = {
                rs.getString("MaSV"),
                rs.getString("HoTen"),
                rs.getDate("NgaySinh"),
                rs.getString("GioiTinh"),
                rs.getString("Email"),
                rs.getString("SDT"),
                rs.getString("DiaChi"),
                rs.getDate("NgayVaoHoc"),
                rs.getString("TrangThai"),
                rs.getString("CCCD"),
                rs.getString("GhiChu"),
                rs.getString("TenLop"),
                rs.getBytes("Anh"), // Lấy dữ liệu ảnh dưới dạng byte[]
                rs.getString("TenDangNhap"), // Lấy tài khoản
                rs.getString("MatKhau") // Lấy mật khẩu
            };
            model.addRow(row);
        }

        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tìm kiếm sinh viên: " + e.getMessage());
    } finally {
        try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_TimKiemSVActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        // Mở lại form DangNhap
    DangNhap dangNhapForm = new DangNhap();
    dangNhapForm.setVisible(true);

    // Đóng form hiện tại
    this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    private void DiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DiemActionPerformed
int selectedRow = jTable3SinhVien.getSelectedRow();

    if (selectedRow != -1) {
        // Giả sử mã sinh viên nằm ở cột 0
        String maSV = jTable3SinhVien.getValueAt(selectedRow, 0).toString();

        // Tạo và mở form DiemSV, truyền mã sinh viên
        DiemSV diemForm = new DiemSV(maSV);
        diemForm.setVisible(true);
        diemForm.setLocationRelativeTo(null); // căn giữa form nếu muốn
    } else {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một sinh viên!");
    }        // TODO add your handling code here:
    }//GEN-LAST:event_DiemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Admin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Admin().setVisible(true);
            }
        });
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextPane CCCD;
    private javax.swing.JTextPane CCCDSV;
    private javax.swing.JButton ChonAnh;
    private javax.swing.JButton ChonAnhSV;
    private javax.swing.JTextPane ChuCVU;
    private javax.swing.JTextPane DiaChi;
    private javax.swing.JTextPane DiaChiSV;
    private javax.swing.JButton Diem;
    private javax.swing.JTextPane Email;
    private javax.swing.JTextPane GhiCHus;
    private javax.swing.JTextPane GhiChuSV;
    private javax.swing.JButton HienTHi;
    private javax.swing.JButton HienThi;
    private javax.swing.JLabel HienThiAnhGV;
    private javax.swing.JLabel HienThiAnhSV;
    private javax.swing.JButton HienThiGV;
    private javax.swing.JButton HienThiSV;
    private javax.swing.JTextPane HoTen;
    private javax.swing.JTextPane MSV;
    private javax.swing.JTextPane MaGV;
    private javax.swing.JTextPane MatKhau;
    private javax.swing.JTextPane MatKhauSV;
    private javax.swing.JTextPane NgayNhapHoc;
    private javax.swing.JTextPane NgaySinh;
    private javax.swing.JTextPane NgaySinhSV;
    private javax.swing.JTextPane NgayVaoLam;
    private javax.swing.JButton ResetSV;
    private javax.swing.JTextPane SDT;
    private javax.swing.JTextPane SDTSV;
    private javax.swing.JButton SuaGV;
    private javax.swing.JButton SuaLHP;
    private javax.swing.JButton SuaSV;
    private javax.swing.JButton TImKiem;
    private javax.swing.JTextPane TaiKhoan;
    private javax.swing.JTextPane TaiKhoanSV;
    private javax.swing.JTextPane TenGV;
    private javax.swing.JButton ThemGV;
    private javax.swing.JButton ThemLHP;
    private javax.swing.JButton ThemSV;
    private javax.swing.JButton TimKiem;
    private javax.swing.JButton TimKiemSV;
    private javax.swing.JTextPane TrinHDo;
    private javax.swing.JButton XoaGV;
    private javax.swing.JButton XoaSV;
    private javax.swing.JButton Xoas;
    private javax.swing.JTextPane emailSV;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3Them;
    private javax.swing.JButton jButton4Sua;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1Khoa;
    private javax.swing.JComboBox<String> jComboBox1MaKH;
    private javax.swing.JComboBox<String> jComboBox1MaNamHoc;
    private javax.swing.JComboBox<String> jComboBox2MonHoc;
    private javax.swing.JComboBox<String> jComboBox2TenCN;
    private javax.swing.JComboBox<String> jComboBox3GioiTinh;
    private javax.swing.JComboBox<String> jComboBox3TenMH;
    private javax.swing.JComboBox<String> jComboBox3TenMonHoc;
    private javax.swing.JComboBox<String> jComboBox4GioiTInh;
    private javax.swing.JComboBox<String> jComboBox4MaNH;
    private javax.swing.JComboBox<String> jComboBox4TenLopHoc;
    private javax.swing.JComboBox<String> jComboBox5BatBuoc;
    private javax.swing.JComboBox<String> jComboBox5Lop;
    private javax.swing.JComboBox<String> jComboBox5TenGiangVien;
    private javax.swing.JComboBox<String> jComboBox6TrangTHai;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4xoa;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane24;
    private javax.swing.JScrollPane jScrollPane25;
    private javax.swing.JScrollPane jScrollPane26;
    private javax.swing.JScrollPane jScrollPane27;
    private javax.swing.JScrollPane jScrollPane28;
    private javax.swing.JScrollPane jScrollPane29;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane30;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTable1GiangVien;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3SinhVien;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextPane jTextPane1MaCCDT;
    private javax.swing.JTextPane jTextPane1MaLHP;
    private javax.swing.JButton reset;
    // End of variables declaration//GEN-END:variables
    private void icon() {
    
    ImageIcon iconGoc1 = new ImageIcon(getClass().getResource("/Style/dowload.png"));
    Image iconThuNho1 = iconGoc1.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    ChonAnh.setIcon(new ImageIcon(iconThuNho1));
    ChonAnh.setHorizontalTextPosition(SwingConstants.RIGHT);
    ChonAnh.setIconTextGap(5);
    ChonAnhSV.setIcon(new ImageIcon(iconThuNho1));
    ChonAnhSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    ChonAnhSV.setIconTextGap(5);
    
    ImageIcon iconGoc2 = new ImageIcon(getClass().getResource("/Style/add.png"));
    Image iconThuNho2 = iconGoc2.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    ThemGV.setIcon(new ImageIcon(iconThuNho2));
    ThemGV.setHorizontalTextPosition(SwingConstants.RIGHT);
    ThemGV.setIconTextGap(5);
    ThemSV.setIcon(new ImageIcon(iconThuNho2));
    ThemSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    ThemSV.setIconTextGap(5);
    jButton3Them.setIcon(new ImageIcon(iconThuNho2));
    jButton3Them.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton3Them.setIconTextGap(5);
            
    ImageIcon iconGoc3 = new ImageIcon(getClass().getResource("/Style/trash.png"));
    Image iconThuNho3 = iconGoc3.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    XoaGV.setIcon(new ImageIcon(iconThuNho3));
    XoaGV.setHorizontalTextPosition(SwingConstants.RIGHT);
    XoaGV.setIconTextGap(5);
    XoaSV.setIcon(new ImageIcon(iconThuNho3));
    XoaSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    XoaSV.setIconTextGap(5);
    Xoas.setIcon(new ImageIcon(iconThuNho3));
    Xoas.setHorizontalTextPosition(SwingConstants.RIGHT);
    Xoas.setIconTextGap(5);
    jButton10.setIcon(new ImageIcon(iconThuNho3));
    jButton10.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton10.setIconTextGap(5);
            
    ImageIcon iconGoc4 = new ImageIcon(getClass().getResource("/Style/display-code.png"));
    Image iconThuNho4 = iconGoc4.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    HienThiGV.setIcon(new ImageIcon(iconThuNho4));
    HienThiGV.setHorizontalTextPosition(SwingConstants.RIGHT);
    HienThiGV.setIconTextGap(5);
    HienThiSV.setIcon(new ImageIcon(iconThuNho4));
    HienThiSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    HienThiSV.setIconTextGap(5);
    HienThi.setIcon(new ImageIcon(iconThuNho4));
    HienThi.setHorizontalTextPosition(SwingConstants.RIGHT);
    HienThi.setIconTextGap(5);
    HienTHi.setIcon(new ImageIcon(iconThuNho4));
    HienTHi.setHorizontalTextPosition(SwingConstants.RIGHT);
    HienTHi.setIconTextGap(5);        
            
    ImageIcon iconGoc5 = new ImageIcon(getClass().getResource("/Style/fix.png"));
    Image iconThuNho5 = iconGoc5.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    SuaGV.setIcon(new ImageIcon(iconThuNho5));
    SuaGV.setHorizontalTextPosition(SwingConstants.RIGHT);
    SuaGV.setIconTextGap(5);
    SuaSV.setIcon(new ImageIcon(iconThuNho5));
    SuaSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    SuaSV.setIconTextGap(5);
    SuaLHP.setIcon(new ImageIcon(iconThuNho5));
    SuaLHP.setHorizontalTextPosition(SwingConstants.RIGHT);
    SuaLHP.setIconTextGap(5);
    jButton4Sua.setIcon(new ImageIcon(iconThuNho5));
    jButton4Sua.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton4Sua.setIconTextGap(5);
    
    ImageIcon iconGoc6 = new ImageIcon(getClass().getResource("/Style/search.png"));
    Image iconThuNho6 = iconGoc6.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    TImKiem.setIcon(new ImageIcon(iconThuNho6));
    TImKiem.setHorizontalTextPosition(SwingConstants.RIGHT);
    TImKiem.setIconTextGap(5);
    TimKiemSV.setIcon(new ImageIcon(iconThuNho6));
    TimKiemSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    TimKiemSV.setIconTextGap(5);
    TimKiem.setIcon(new ImageIcon(iconThuNho6));
    TimKiem.setHorizontalTextPosition(SwingConstants.RIGHT);
    TimKiem.setIconTextGap(5);
     jButton14.setIcon(new ImageIcon(iconThuNho6));
    jButton14.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton14.setIconTextGap(5);
    
    ImageIcon iconGoc7 = new ImageIcon(getClass().getResource("/Style/reset.png"));
    Image iconThuNho7 = iconGoc7.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    reset.setIcon(new ImageIcon(iconThuNho7));
    reset.setHorizontalTextPosition(SwingConstants.RIGHT);
    reset.setIconTextGap(5);
    ResetSV.setIcon(new ImageIcon(iconThuNho7));
    ResetSV.setHorizontalTextPosition(SwingConstants.RIGHT);
    ResetSV.setIconTextGap(5);
    jButton12.setIcon(new ImageIcon(iconThuNho7));
    jButton12.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton12.setIconTextGap(5);
    
    ImageIcon iconGoc8 = new ImageIcon(getClass().getResource("/Style/entrance.png"));
    Image iconThuNho8 = iconGoc8.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton1.setIcon(new ImageIcon(iconThuNho8));
    jButton1.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton1.setIconTextGap(5);
}
private void tuyChinhGiaoDien() {
    // Đặt màu nền nếu bạn muốn giao diện đồng bộ
    this.getContentPane().setBackground(Color.decode("#F5F5FA"));
}
}
