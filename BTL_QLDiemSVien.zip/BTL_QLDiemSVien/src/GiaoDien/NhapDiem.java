/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GiaoDien;
import Style.GiaoDienMacDinh;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.File;
import java.io.FileInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
import javax.imageio.ImageIO;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
/**
 *
 * @author thuan
 */
public class NhapDiem extends javax.swing.JFrame {

    /**
     * Creates new form NhapDiem
     */
    public NhapDiem() {
        initComponents();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        GiaoDienMacDinh.caiDatFlatLaf();
        icon();
        hienThiLogo();
        tuyChinhGiaoDien();
    }
    public NhapDiem(String maLHP) {
    initComponents(); // Khởi tạo giao diện
setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
    if (maLHP != null && !maLHP.trim().isEmpty()) {
        HienThiMaHP.setText(maLHP); // Hiển thị mã lớp học phần
        hienThiDanhSachSinhVien(maLHP); // Hiển thị danh sách sinh viên ngay khi form mở
    } else {
        JOptionPane.showMessageDialog(null, "❌ Mã lớp học phần không hợp lệ!");
    }
}
public void setThongTinMonHoc(String maHP, String tenMon, String maLop) {
    HienThiMaHP.setText(maHP);
    hienThiMonHoc.setText(tenMon);
    HienThiLopHoc.setText(maLop);
}
public void hienThiDanhSachSinhVien(String maLHP) {
    DefaultTableModel model = (DefaultTableModel) jTable1HienThiDanhSachLop.getModel();
    model.setRowCount(0); // Xóa dữ liệu cũ trước khi hiển thị mới

    String sql = "SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, " +
                 "COALESCE(d.DiemCC, 0) AS DiemCC, " +
                 "COALESCE(d.DiemGK, 0) AS DiemGK, " +
                 "COALESCE(d.DiemCK, 0) AS DiemCK " +
                 "FROM LopHocPhan lhp " +
                 "JOIN SinhVien sv ON sv.MaLop = lhp.MaLop " +
                 "LEFT JOIN Diem d ON sv.MaSV = d.MaSV AND d.MaLHP = lhp.MaLHP " +
                 "WHERE lhp.MaLHP = ? " +
                 "ORDER BY sv.HoTen ASC";

    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, maLHP);
        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("MaSV"),
                rs.getString("HoTen"),
                rs.getDate("NgaySinh"),
                rs.getString("GioiTinh"),
                rs.getFloat("DiemCC"),
                rs.getFloat("DiemGK"),
                rs.getFloat("DiemCK")
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "❌ Lỗi khi tải danh sách sinh viên!");
    }
}
public void setThongTinSinhVien(String maSV, String hoTen, String ngaySinh, String gioiTinh, String diemCC, String diemGK, String diemCK) {
    MSV.setText(maSV);
    HoVaTen.setText(hoTen);
    NgaySinh.setText(ngaySinh);
    GioiTinh.setText(gioiTinh);
    DiemCC.setText(diemCC);
    DiemGk.setText(diemGK);
    DiemCK.setText(diemCK);
    
}
private void jTable1HienThiDanhSachLopMouseClicked(java.awt.event.MouseEvent evt) {
    int row = jTable1HienThiDanhSachLop.getSelectedRow(); // Lấy dòng được chọn

    if (row != -1) {
        Object objMaSV = jTable1HienThiDanhSachLop.getValueAt(row, 0);
        Object objHoTen = jTable1HienThiDanhSachLop.getValueAt(row, 1);
        Object objNgaySinh = jTable1HienThiDanhSachLop.getValueAt(row, 2);
        Object objGioiTinh = jTable1HienThiDanhSachLop.getValueAt(row, 3);
        Object objDiemCC = jTable1HienThiDanhSachLop.getValueAt(row, 4);
        Object objDiemGK = jTable1HienThiDanhSachLop.getValueAt(row, 5);
        Object objDiemCK = jTable1HienThiDanhSachLop.getValueAt(row, 6);

        String maSV = (objMaSV instanceof String) ? (String) objMaSV : "";
        String hoTen = (objHoTen instanceof String) ? (String) objHoTen : "";
        String ngaySinh = (objNgaySinh instanceof Date) ? objNgaySinh.toString() : "";
        String gioiTinh = (objGioiTinh instanceof String) ? (String) objGioiTinh : "";
        String diemCC = (objDiemCC instanceof Number) ? String.valueOf(objDiemCC) : "0";
        String diemGK = (objDiemGK instanceof Number) ? String.valueOf(objDiemGK) : "0";
        String diemCK = (objDiemCK instanceof Number) ? String.valueOf(objDiemCK) : "0";

        // Hiển thị dữ liệu lên giao diện
        setThongTinSinhVien(maSV, hoTen, ngaySinh, gioiTinh, diemCC, diemGK, diemCK);
    }
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1HienThiDanhSachLop = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        MSV = new javax.swing.JTextPane();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        HoVaTen = new javax.swing.JTextPane();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        NgaySinh = new javax.swing.JTextPane();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        GioiTinh = new javax.swing.JTextPane();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        DiemCC = new javax.swing.JTextPane();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        DiemGk = new javax.swing.JTextPane();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        DiemCK = new javax.swing.JTextPane();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        hienThiMonHoc = new javax.swing.JLabel();
        HienThiLopHoc = new javax.swing.JLabel();
        Luu = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        HienThiMaHP = new javax.swing.JLabel();
        reset = new javax.swing.JButton();
        Chon = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1HienThiDanhSachLop.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sinh viên", "Họ và Tên", "Ngày Sinh", "Giới tính", "Điểm Chuyên cần", "Điểm Giữa Kì", "Điểm Cuối kì"
            }
        ));
        jScrollPane1.setViewportView(jTable1HienThiDanhSachLop);

        jLabel1.setText("Mã sinh viên");

        MSV.setEditable(false);
        jScrollPane2.setViewportView(MSV);

        jLabel2.setText("Họ và Tên");

        HoVaTen.setEditable(false);
        jScrollPane3.setViewportView(HoVaTen);

        jLabel3.setText("Ngày sinh");

        NgaySinh.setEditable(false);
        jScrollPane4.setViewportView(NgaySinh);

        jLabel4.setText("Giới tính");

        GioiTinh.setEditable(false);
        jScrollPane5.setViewportView(GioiTinh);

        jLabel5.setText("Hiển thị ảnh sinh viên");

        jScrollPane6.setViewportView(DiemCC);

        jLabel6.setText("Điểm Chuyên cần");

        jScrollPane7.setViewportView(DiemGk);

        jLabel7.setText("Điểm Giữa Kì");

        jScrollPane8.setViewportView(DiemCK);

        jLabel8.setText("Điểm Cuối Kì");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel9.setText("Môn học: ");

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel10.setText("Lớp: ");

        hienThiMonHoc.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        hienThiMonHoc.setText("Hiển  thị môn học");

        HienThiLopHoc.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        HienThiLopHoc.setText("Hiển thị lớp học");

        Luu.setText("Lưu");
        Luu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LuuActionPerformed(evt);
            }
        });

        jLabel11.setText("Mã học phần: ");

        HienThiMaHP.setText("Hiển thị mã học phần");

        reset.setText("reset");
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        Chon.setText("Chọn");
        Chon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(32, 32, 32)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane4)
                                    .addComponent(jLabel4)
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jScrollPane6)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(Luu)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Chon)))
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jScrollPane7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jScrollPane8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel7)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(HienThiLopHoc, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel11)
                                        .addGap(32, 32, 32)
                                        .addComponent(HienThiMaHP, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(25, 25, 25))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(hienThiMonHoc)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(reset))))))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(reset, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel9)
                                .addComponent(hienThiMonHoc)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(HienThiLopHoc)
                            .addComponent(jLabel11)
                            .addComponent(HienThiMaHP))
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel3))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel6)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel4))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(1, 1, 1))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(Chon)
                                .addComponent(Luu))))
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 574, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
        String maLHP = HienThiMaHP.getText(); // Lấy mã lớp học phần từ JLabel

    if (maLHP != null && !maLHP.trim().isEmpty()) {
        hienThiDanhSachSinhVien(maLHP); // Hiển thị danh sách sinh viên
    } else {
        JOptionPane.showMessageDialog(null, "❌ Mã lớp học phần không hợp lệ!");
    }

    }//GEN-LAST:event_resetActionPerformed

    private void ChonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChonActionPerformed
        // TODO add your handling code here:
        int row = jTable1HienThiDanhSachLop.getSelectedRow(); // Lấy dòng được chọn

    if (row != -1) {
        // Lấy dữ liệu từ dòng được chọn với kiểm tra kiểu dữ liệu
        Object objMaSV = jTable1HienThiDanhSachLop.getValueAt(row, 0);
        Object objHoTen = jTable1HienThiDanhSachLop.getValueAt(row, 1);
        Object objNgaySinh = jTable1HienThiDanhSachLop.getValueAt(row, 2);
        Object objGioiTinh = jTable1HienThiDanhSachLop.getValueAt(row, 3);
        Object objDiemCC = jTable1HienThiDanhSachLop.getValueAt(row, 4);
        Object objDiemGK = jTable1HienThiDanhSachLop.getValueAt(row, 5);
        Object objDiemCK = jTable1HienThiDanhSachLop.getValueAt(row, 6);

        // Kiểm tra kiểu dữ liệu để tránh lỗi
        String maSV = (objMaSV instanceof String) ? (String) objMaSV : "";
        String hoTen = (objHoTen instanceof String) ? (String) objHoTen : "";
        String ngaySinh = (objNgaySinh instanceof Date) ? objNgaySinh.toString() : "";
        String gioiTinh = (objGioiTinh instanceof String) ? (String) objGioiTinh : "";
        String diemCC = (objDiemCC instanceof Number) ? String.valueOf(objDiemCC) : "0";
        String diemGK = (objDiemGK instanceof Number) ? String.valueOf(objDiemGK) : "0";
        String diemCK = (objDiemCK instanceof Number) ? String.valueOf(objDiemCK) : "0";

        // Hiển thị dữ liệu lên giao diện
        setThongTinSinhVien(maSV, hoTen, ngaySinh, gioiTinh, diemCC, diemGK, diemCK);
    } else {
        JOptionPane.showMessageDialog(null, "❌ Bạn chưa chọn sinh viên nào!");
    }

    }//GEN-LAST:event_ChonActionPerformed

    private void LuuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LuuActionPerformed
        // TODO add your handling code here:
        // Lấy giá trị từ các thành phần giao diện
    String maSV = MSV.getText().trim();
    String maLHP = HienThiMaHP.getText().trim();
    float diemCC, diemGK, diemCK;
    
    // Kiểm tra định dạng điểm
    try {
        diemCC = Float.parseFloat(DiemCC.getText().trim());
        diemGK = Float.parseFloat(DiemGk.getText().trim());
        diemCK = Float.parseFloat(DiemCK.getText().trim());
    } catch (NumberFormatException ex) {
        JOptionPane.showMessageDialog(null, "Vui lòng nhập đúng định dạng điểm (số).");
        return;
    }
    
    // Câu SQL để cập nhật điểm nếu bản ghi tồn tại
    String sqlUpdate = "UPDATE Diem SET DiemCC = ?, DiemGK = ?, DiemCK = ? WHERE MaSV = ? AND MaLHP = ?";
    
    try (Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
         PreparedStatement pstmt = conn.prepareStatement(sqlUpdate)) {
         
         pstmt.setFloat(1, diemCC);
         pstmt.setFloat(2, diemGK);
         pstmt.setFloat(3, diemCK);
         pstmt.setString(4, maSV);
         pstmt.setString(5, maLHP);
         
         int rowsUpdated = pstmt.executeUpdate();
         
         if (rowsUpdated == 0) {
             // Nếu không cập nhật được (bản ghi chưa tồn tại) thì thực hiện INSERT
             String sqlInsert = "INSERT INTO Diem (MaSV, MaLHP, DiemCC, DiemGK, DiemCK) VALUES (?, ?, ?, ?, ?)";
             try (PreparedStatement pstmt2 = conn.prepareStatement(sqlInsert)) {
                 pstmt2.setString(1, maSV);
                 pstmt2.setString(2, maLHP);
                 pstmt2.setFloat(3, diemCC);
                 pstmt2.setFloat(4, diemGK);
                 pstmt2.setFloat(5, diemCK);
                 
                 pstmt2.executeUpdate();
             }
             JOptionPane.showMessageDialog(null, "Điểm sinh viên đã được lưu (INSERT).");
         } else {
             JOptionPane.showMessageDialog(null, "Điểm sinh viên đã được cập nhật (UPDATE).");
         }
         
    } catch (Exception e) {
         e.printStackTrace();
         JOptionPane.showMessageDialog(null, "Lỗi khi lưu điểm sinh viên: " + e.getMessage());
    }

    }//GEN-LAST:event_LuuActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NhapDiem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NhapDiem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NhapDiem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NhapDiem.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NhapDiem().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Chon;
    private javax.swing.JTextPane DiemCC;
    private javax.swing.JTextPane DiemCK;
    private javax.swing.JTextPane DiemGk;
    private javax.swing.JTextPane GioiTinh;
    private javax.swing.JLabel HienThiLopHoc;
    private javax.swing.JLabel HienThiMaHP;
    private javax.swing.JTextPane HoVaTen;
    private javax.swing.JButton Luu;
    private javax.swing.JTextPane MSV;
    private javax.swing.JTextPane NgaySinh;
    private javax.swing.JLabel hienThiMonHoc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTable jTable1HienThiDanhSachLop;
    private javax.swing.JButton reset;
    // End of variables declaration//GEN-END:variables
private void icon() {
    
    ImageIcon iconGoc2 = new ImageIcon(getClass().getResource("/Style/choose.png"));
    Image iconThuNho2 = iconGoc2.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    Chon.setIcon(new ImageIcon(iconThuNho2));
    Chon.setHorizontalTextPosition(SwingConstants.RIGHT);
    Chon.setIconTextGap(5);

    ImageIcon iconGoc3 = new ImageIcon(getClass().getResource("/Style/save.png"));
    Image iconThuNho3 = iconGoc3.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    Luu.setIcon(new ImageIcon(iconThuNho3));
    Luu.setHorizontalTextPosition(SwingConstants.RIGHT);
    Luu.setIconTextGap(5);

    ImageIcon iconGoc7 = new ImageIcon(getClass().getResource("/Style/reset.png"));
    Image iconThuNho7 = iconGoc7.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    reset.setIcon(new ImageIcon(iconThuNho7));
    reset.setHorizontalTextPosition(SwingConstants.RIGHT);
    reset.setIconTextGap(5);
    
}
private void hienThiLogo() {
    URL imageURL = getClass().getResource("/Style/logo.png");
    if (imageURL != null) {
        ImageIcon icon = new ImageIcon(imageURL);
        Image image = icon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH); // Tăng kích thước
        ImageIcon scaledIcon = new ImageIcon(image);

        jLabel13.setIcon(scaledIcon);
        jLabel13.setHorizontalAlignment(SwingConstants.CENTER);

        
    } else {
        System.err.println("Không tìm thấy ảnh logo.png");
    }
}
private void tuyChinhGiaoDien() {
    // Đặt màu nền nếu bạn muốn giao diện đồng bộ
    this.getContentPane().setBackground(Color.decode("#F5F5FA"));
}
}
