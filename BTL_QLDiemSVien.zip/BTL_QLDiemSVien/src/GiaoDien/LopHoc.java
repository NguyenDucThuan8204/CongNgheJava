/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package GiaoDien;
import Style.GiaoDienMacDinh;
import java.awt.Color;
import java.awt.Image;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
/**
 *
 * @author thuan
 */
public class LopHoc extends javax.swing.JFrame {
// Đặt ở đầu class JFrame (biến toàn cục)
private Map<String, String> mapTenCNtoMaCN = new HashMap<>();
String selectedCN;
    /**
     * Creates new form LopHoc
     */
    public LopHoc() {
        initComponents();
        loadDataToTableLop();
        loadComboBoxMaKhoaHoc();
        loadComboBoxTenCN();
        loadChuyenNganhToComboBox();
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        GiaoDienMacDinh.caiDatFlatLaf();
        icon();
        tuyChinhGiaoDien();
    }
    private void loadChuyenNganhToComboBox() {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }

    try {
        String sql = "SELECT DISTINCT CN.MaCN, CN.TenCN " +
                     "FROM Lop L INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        // Xóa dữ liệu cũ
        jComboBox4CN.removeAllItems();
        mapTenCNtoMaCN.clear();

        // Dòng đầu tiên mặc định
        jComboBox4CN.addItem("-- Chọn chuyên ngành --");
        mapTenCNtoMaCN.put("-- Chọn chuyên ngành --", null);

        while (rs.next()) {
            String maCN = rs.getString("MaCN");
            String tenCN = rs.getString("TenCN");

            jComboBox4CN.addItem(tenCN);                // hiển thị Tên CN
            mapTenCNtoMaCN.put(tenCN, maCN);            // ánh xạ TenCN → MaCN
        }

        rs.close();
        pst.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải chuyên ngành: " + e.getMessage());
    }
}



    private void loadComboBoxMaKhoaHoc() {
    // Kết nối đến CSDL
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }
    
    try {
        // Truy vấn toàn bộ mã khóa học từ bảng KhoaHoc
        String sql = "SELECT MaKhoaHoc FROM KhoaHoc";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        // Xóa các mục cũ hiện có trong jComboBox2MaKhoaHoc
        jComboBox2MaKhoaHoc.removeAllItems();
        // Thêm mục mặc định
        jComboBox2MaKhoaHoc.addItem("Chọn mã khóa học");
        
        // Các dòng dữ liệu: thêm mã khóa học vào ComboBox
        while (rs.next()) {
            String maKhoaHoc = rs.getString("MaKhoaHoc");
            jComboBox2MaKhoaHoc.addItem(maKhoaHoc);
        }
        
        rs.close();
        pst.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu mã khóa học: " + e.getMessage());
    }
}
    private void loadComboBoxTenCN() {
    // Kết nối đến CSDL
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }
    
    try {
        // Truy vấn toàn bộ tên chuyên ngành từ bảng ChuyenNganh
        String sql = "SELECT TenCN FROM ChuyenNganh";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        // Xóa các mục cũ hiện có trong jComboBox1CN
        jComboBox1CN.removeAllItems();
        // Thêm mục mặc định (nếu cần)
        jComboBox1CN.addItem("Chọn chuyên ngành");
        
        // Duyệt qua từng bản ghi và thêm tên chuyên ngành vào ComboBox
        while (rs.next()) {
            String tenCN = rs.getString("TenCN");
            jComboBox1CN.addItem(tenCN);
        }
        
        rs.close();
        pst.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu chuyên ngành: " + e.getMessage());
    }
}
private void loadDataToTableLop() {
    // Kết nối đến cơ sở dữ liệu theo method được định nghĩa sẵn
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }
    
    try {
        // Câu truy vấn JOIN để lấy thông tin lớp cần hiển thị (bỏ thông tin tên khoa)
        String sql = "SELECT L.MaLop, L.TenLop, CN.TenCN, L.MaKhoaHoc " +
                     "FROM Lop L " +
                     "INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN";
                     
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();
        
        // Lấy đối tượng model của jTable1Lop và xóa dữ liệu cũ
        DefaultTableModel model = (DefaultTableModel) jTable1Lop.getModel();
        model.setRowCount(0);
        
        // Duyệt từng dòng của kết quả truy vấn và thêm vào model
        while (rs.next()) {
            String maLop     = rs.getString("MaLop");
            String tenLop    = rs.getString("TenLop");
            String tenCN     = rs.getString("TenCN");     
            String maKhoaHoc = rs.getString("MaKhoaHoc");
            
            // Lưu ý: Điều chỉnh lại số lượng cột theo định nghĩa của model (ví dụ: 4 cột)
            Object[] row = { maLop, tenLop, tenCN, maKhoaHoc };
            model.addRow(row);
        }
        
        // Đóng tài nguyên
        rs.close();
        pst.close();
        conn.close();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu lớp: " + e.getMessage());
    }
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1Lop = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextPane1 = new javax.swing.JTextPane();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextPane2 = new javax.swing.JTextPane();
        jComboBox1CN = new javax.swing.JComboBox<>();
        jComboBox2MaKhoaHoc = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        HienThi = new javax.swing.JButton();
        jButton2xoa = new javax.swing.JButton();
        jButton3sua = new javax.swing.JButton();
        jButton4Them = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6TimKiem = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jComboBox4CN = new javax.swing.JComboBox<>();
        jComboBox5KhoaHoc = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jLabel1.setText("Quản lý Lớp");

        jTable1Lop.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mã Lớp", "Tên Lớp", "Tên Chuyên Ngành", "Mã khóa học"
            }
        ));
        jScrollPane1.setViewportView(jTable1Lop);

        jScrollPane2.setViewportView(jTextPane1);

        jScrollPane3.setViewportView(jTextPane2);

        jComboBox1CN.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jComboBox2MaKhoaHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel2.setText("Mã Lớp");

        jLabel3.setText("Tên Lớp");

        jLabel4.setText("Tên Chuyên Ngành");

        jLabel5.setText("Tên khóa học");

        HienThi.setText("Hiển thị");
        HienThi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HienThiActionPerformed(evt);
            }
        });

        jButton2xoa.setText("Xóa");
        jButton2xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2xoaActionPerformed(evt);
            }
        });

        jButton3sua.setText("Sửa");
        jButton3sua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3suaActionPerformed(evt);
            }
        });

        jButton4Them.setText("Thêm");
        jButton4Them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ThemActionPerformed(evt);
            }
        });

        jButton5.setText("Reset");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6TimKiem.setText("Tìm Kiếm");
        jButton6TimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6TimKiemActionPerformed(evt);
            }
        });

        jLabel6.setText("Tìm Kiếm: ");

        jLabel8.setText("Chuyên ngành");

        jLabel9.setText("Khóa");

        jComboBox4CN.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox4CN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4CNActionPerformed(evt);
            }
        });

        jComboBox5KhoaHoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox5KhoaHoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox5KhoaHocActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton4Them)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jButton5)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel6))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(jButton3sua, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jButton6TimKiem, javax.swing.GroupLayout.Alignment.LEADING)))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jComboBox1CN, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(jButton2xoa)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jComboBox2MaKhoaHoc, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(HienThi)
                                            .addComponent(jLabel5)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8)
                                            .addComponent(jComboBox4CN, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jComboBox5KhoaHoc, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(146, 146, 146)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 105, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(5, 5, 5)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(7, 7, 7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jComboBox1CN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jComboBox2MaKhoaHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(HienThi)
                            .addComponent(jButton2xoa)
                            .addComponent(jButton3sua)
                            .addComponent(jButton4Them))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton5)
                            .addComponent(jButton6TimKiem))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jComboBox4CN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jComboBox5KhoaHoc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 1, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel5)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
private void loadDataToTableLopForKhoa(String tenKhoa) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    try {
        String sql = "SELECT L.MaLop, L.TenLop, K.TenKhoa, CN.TenCN, L.MaKhoaHoc " +
                     "FROM Lop L " +
                     "INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN " +
                     "INNER JOIN Khoa K ON CN.MaKhoa = K.MaKhoa " +
                     "WHERE K.TenKhoa = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenKhoa);
        ResultSet rs = pst.executeQuery();
        DefaultTableModel model = (DefaultTableModel) jTable1Lop.getModel();
        model.setRowCount(0);
        while(rs.next()){
            Object[] row = {
                rs.getString("MaLop"),
                rs.getString("TenLop"),
                rs.getString("TenKhoa"),
                rs.getString("TenCN"),
                rs.getString("MaKhoaHoc")
            };
            model.addRow(row);
        }
        rs.close();
        pst.close();
        conn.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải Lớp của khoa: " + e.getMessage());
    }
}
private void loadComboBox4CNForKhoa(String tenKhoa) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    try {
        // Lấy tên chuyên ngành từ bảng ChuyenNganh (theo khoa)
        String sql = "SELECT DISTINCT CN.TenCN " +
                     "FROM ChuyenNganh CN " +
                     "INNER JOIN Khoa K ON CN.MaKhoa = K.MaKhoa " +
                     "WHERE K.TenKhoa = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenKhoa);
        ResultSet rs = pst.executeQuery();
        jComboBox4CN.removeAllItems();
        jComboBox4CN.addItem("Chọn chuyên ngành");
        while(rs.next()){
            String tenCN = rs.getString("TenCN");
            jComboBox4CN.addItem(tenCN);
        }
        rs.close();
        pst.close();
        conn.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi tải dữ liệu Chuyên ngành: " + e.getMessage());
    }
}
private void loadDataToTableLopForCN(String selectedCN) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối!");
        return;
    }
    try {
        String sql = "SELECT L.MaLop, L.TenLop, CN.TenCN, L.MaKhoaHoc " +
                     "FROM Lop L " +
                     "INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN " +
                     "WHERE CN.TenCN = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, selectedCN);
        ResultSet rs = pst.executeQuery();
        
        DefaultTableModel model = (DefaultTableModel) jTable1Lop.getModel();
        model.setRowCount(0);
        
        while(rs.next()){
            Object[] row = {
                rs.getString("MaLop"),
                rs.getString("TenLop"),
                rs.getString("TenCN"),
                rs.getString("MaKhoaHoc")
            };
            model.addRow(row);
        }
        rs.close();
        pst.close();
        conn.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải lớp theo chuyên ngành: " + e.getMessage());
    }
}
private void loadComboBox5KhoaHocForCN(String tenCN) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    
    try {
        // Lấy danh sách khóa học (distinct) từ bảng Lop dựa vào chuyên ngành được chọn
        String sql = "SELECT DISTINCT L.MaKhoaHoc " +
                     "FROM Lop L " +
                     "INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN " +
                     "WHERE CN.TenCN = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenCN);
        ResultSet rs = pst.executeQuery();
        
        // Reset dữ liệu trong jComboBox5KhoaHoc, thêm mục mặc định
        jComboBox5KhoaHoc.removeAllItems();
        jComboBox5KhoaHoc.addItem("Chọn khóa học");
        
        // Duyệt qua các kết quả và thêm vào ComboBox
        while (rs.next()) {
            String maKH = rs.getString("MaKhoaHoc");
            jComboBox5KhoaHoc.addItem(maKH);
        }
        
        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu các khóa học: " + e.getMessage());
    } finally {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    private void jComboBox4CNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4CNActionPerformed
// Lấy tên chuyên ngành được chọn từ ComboBox
    String tenCN = (String) jComboBox4CN.getSelectedItem();

    // Nếu không chọn hoặc chọn mục mặc định, load toàn bộ lớp và reset jComboBox5KhoaHoc
    if (tenCN == null || tenCN.equals("-- Chọn chuyên ngành --")) {
        loadDataToTableLop();
        jComboBox5KhoaHoc.removeAllItems();
        jComboBox5KhoaHoc.addItem("Chọn khóa học");
        return;
    }

    // Nếu đã chọn chuyên ngành, hiển thị các lớp có chuyên ngành đó lên bảng
    loadDataToTableLopForCN(tenCN);
    
    // Sau đó, load danh sách khóa học của chuyên ngành đó lên jComboBox5KhoaHoc
    loadComboBox5KhoaHocForCN(tenCN);


    }//GEN-LAST:event_jComboBox4CNActionPerformed
private void loadDataToTableLopForCNAndKH(String selectedCN, String selectedKH) {
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối!");
        return;
    }
    
    try {
        String sql = "SELECT L.MaLop, L.TenLop, CN.TenCN, L.MaKhoaHoc " +
                     "FROM Lop L " +
                     "INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN " +
                     "WHERE CN.TenCN = ? AND L.MaKhoaHoc = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, selectedCN);
        pst.setString(2, selectedKH);
        ResultSet rs = pst.executeQuery();
        
        DefaultTableModel model = (DefaultTableModel) jTable1Lop.getModel();
        model.setRowCount(0); // Xóa dữ liệu cũ
        
        while (rs.next()) {
            Object[] row = {
                rs.getString("MaLop"),
                rs.getString("TenLop"),
                rs.getString("TenCN"),
                rs.getString("MaKhoaHoc")
            };
            model.addRow(row);
        }
        
        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tải dữ liệu lớp theo chuyên ngành và khóa học: " + e.getMessage());
    } finally {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
    private void jComboBox5KhoaHocActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox5KhoaHocActionPerformed
// Lấy giá trị khóa học được chọn
    String selectedKH = (String) jComboBox5KhoaHoc.getSelectedItem();
    
    // Kiểm tra nếu chưa chọn hoặc chọn mục mặc định
    if (selectedKH == null || selectedKH.equals("Chọn khóa học")) {
        // Tùy chọn: nếu không chọn khóa học, có thể hiển thị lại các lớp theo chuyên ngành đã chọn
        String selectedCN = (String) jComboBox4CN.getSelectedItem();
        if (selectedCN != null && !selectedCN.equals("-- Chọn chuyên ngành --")) {
            loadDataToTableLopForCN(selectedCN);
        } else {
            loadDataToTableLop();
        }
        return;
    }
    
    // Lấy tên chuyên ngành đang được chọn từ jComboBox4CN
    String selectedCN = (String) jComboBox4CN.getSelectedItem();
    if (selectedCN == null || selectedCN.equals("-- Chọn chuyên ngành --")) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn chuyên ngành trước!");
        return;
    }
    
    // Hiển thị các lớp có chuyên ngành và khóa học được chọn
    loadDataToTableLopForCNAndKH(selectedCN, selectedKH);

    }//GEN-LAST:event_jComboBox5KhoaHocActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed

        loadDataToTableLopForCN(selectedCN);
        loadDataToTableLop();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton4ThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ThemActionPerformed
// Lấy dữ liệu từ giao diện (đảm bảo rằng các ô không trống; thay tên component tương ứng nếu khác)
    String maLop = jTextPane1.getText().trim();
    String tenLop = jTextPane2.getText().trim();
    Object objCN = jComboBox1CN.getSelectedItem();
    Object objMaKH = jComboBox2MaKhoaHoc.getSelectedItem();

    if(maLop.isEmpty() || tenLop.isEmpty() || objCN == null || objMaKH == null
       || objCN.toString().equals("Chọn chuyên ngành") || objMaKH.toString().equals("Chọn mã khóa học")) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    String tenCN = objCN.toString(); // tên chuyên ngành
    String maKhoaHoc = objMaKH.toString(); // mã khóa học

    // Giả sử bạn có hàm getMaCNByTen(String tenCN) để lấy Ra MaCN
    String maCN = getMaCNByTen(tenCN);
    if(maCN == null || maCN.equals("")) {
        JOptionPane.showMessageDialog(this, "Không xác định được mã chuyên ngành từ tên chuyên ngành!");
        return;
    }

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    try {
        String sql = "INSERT INTO Lop (MaLop, TenLop, MaCN, MaKhoaHoc) VALUES (?,?,?,?)";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, maLop);
        pst.setString(2, tenLop);
        pst.setString(3, maCN);
        pst.setString(4, maKhoaHoc);

        int rowsInserted = pst.executeUpdate();
        if(rowsInserted > 0) {
            JOptionPane.showMessageDialog(this, "Thêm lớp thành công!");
            loadDataToTableLop(); // Hàm này load lại toàn bộ dữ liệu lên jTable1Lop
        } else {
            JOptionPane.showMessageDialog(this, "Thêm lớp thất bại!");
        }
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "Lỗi khi thêm lớp: " + e.getMessage());
    } finally {
        try { conn.close(); } catch(SQLException ex) { }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ThemActionPerformed
private String getMaCNByTen(String tenCN) {
    String maCN = "";
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return "";
    }
    
    try {
        String sql = "SELECT MaCN FROM ChuyenNganh WHERE TenCN = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenCN);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            maCN = rs.getString("MaCN");
        }
        rs.close();
        pst.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi lấy MaCN: " + e.getMessage());
    } finally {
        try {
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    
    return maCN;
}
    private void jButton3suaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3suaActionPerformed
String maLop = jTextPane1.getText().trim();
    String tenLop = jTextPane2.getText().trim();
    Object objCN = jComboBox1CN.getSelectedItem();
    Object objMaKH = jComboBox2MaKhoaHoc.getSelectedItem();

    if(maLop.isEmpty() || tenLop.isEmpty() || objCN == null || objMaKH == null
       || objCN.toString().equals("Chọn chuyên ngành") || objMaKH.toString().equals("Chọn mã khóa học")) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    String tenCN = objCN.toString();
    String maKhoaHoc = objMaKH.toString();
    String maCN = getMaCNByTen(tenCN);
    if(maCN == null || maCN.equals("")) {
        JOptionPane.showMessageDialog(this, "Không xác định được mã chuyên ngành!");
        return;
    }

    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL");
        return;
    }
    try {
        String sql = "UPDATE Lop SET TenLop = ?, MaCN = ?, MaKhoaHoc = ? WHERE MaLop = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, tenLop);
        pst.setString(2, maCN);
        pst.setString(3, maKhoaHoc);
        pst.setString(4, maLop);

        int rowsUpdated = pst.executeUpdate();
        if(rowsUpdated > 0) {
            JOptionPane.showMessageDialog(this, "Cập nhật lớp thành công!");
            loadDataToTableLop();
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy lớp để cập nhật!");
        }
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "Lỗi khi cập nhật lớp: " + e.getMessage());
    } finally {
        try { conn.close(); } catch(SQLException ex) { }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3suaActionPerformed

    private void jButton2xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2xoaActionPerformed
String maLop = jTextPane1.getText().trim();
    if(maLop.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Vui lòng nhập mã lớp cần xóa!");
        return;
    }
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if(conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối CSDL!");
        return;
    }
    try {
        String sql = "DELETE FROM Lop WHERE MaLop = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, maLop);
        int rowsDeleted = pst.executeUpdate();
        if(rowsDeleted > 0) {
            JOptionPane.showMessageDialog(this, "Xóa lớp thành công!");
            loadDataToTableLop();
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy lớp để xóa!");
        }
        pst.close();
    } catch(SQLException e) {
        JOptionPane.showMessageDialog(this, "Lỗi khi xóa lớp: " + e.getMessage());
    } finally {
        try { conn.close(); } catch(SQLException ex) { }
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton2xoaActionPerformed

    private void HienThiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HienThiActionPerformed
// Lấy chỉ số dòng đã chọn trong bảng
    int selectedRow = jTable1Lop.getSelectedRow();
    
    // Nếu chưa chọn dòng nào thì thông báo cho người dùng
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Vui lòng chọn một lớp từ bảng!");
        return;
    }
    
    // Lấy model của bảng
    DefaultTableModel model = (DefaultTableModel) jTable1Lop.getModel();
    
    // Lấy thông tin từ các cột cụ thể
    String maLop = model.getValueAt(selectedRow, 0).toString();
    String tenLop = model.getValueAt(selectedRow, 1).toString();
    String tenCN = model.getValueAt(selectedRow, 2).toString();   // Sửa lại: index 2 thay vì index 3
    String maKhoaHoc = model.getValueAt(selectedRow, 3).toString(); // Sửa lại: index 3 thay vì index 4
    
    // Hiển thị thông tin lên các thành phần giao diện
    jTextPane1.setText(maLop);
    jTextPane2.setText(tenLop);
    
    // Đặt giá trị chọn của các ComboBox tương ứng
    // Chú ý: Các ComboBox này phải đã được đổ dữ liệu trước đó gồm có các giá trị chứa "tenCN" và "maKhoaHoc"
    jComboBox1CN.setSelectedItem(tenCN);
    jComboBox2MaKhoaHoc.setSelectedItem(maKhoaHoc);

    }//GEN-LAST:event_HienThiActionPerformed

    private void jButton6TimKiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6TimKiemActionPerformed
// Lấy giá trị tìm kiếm từ các ô nhập liệu
    String searchMaLop = jTextPane1.getText().trim();
    String searchTenLop = jTextPane2.getText().trim();
    
    // Kết nối đến CSDL
    Connection conn = btl_qldiemsvien.CSDL.KetNoiCSDL.connect();
    if (conn == null) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi kết nối cơ sở dữ liệu!");
        return;
    }
    
    try {
        // Sử dụng câu truy vấn với điều kiện LIKE cho mã lớp và tên lớp
        String sql = "SELECT L.MaLop, L.TenLop, CN.TenCN, L.MaKhoaHoc " +
                     "FROM Lop L " +
                     "INNER JOIN ChuyenNganh CN ON L.MaCN = CN.MaCN " +
                     "WHERE L.MaLop LIKE ? AND L.TenLop LIKE ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        
        // Dùng ký tự đại diện % cho phép tìm kiếm chứa chuỗi
        pst.setString(1, "%" + searchMaLop + "%");
        pst.setString(2, "%" + searchTenLop + "%");
        
        ResultSet rs = pst.executeQuery();
        
        // Lấy model của jTable1Lop và xoá dữ liệu cũ
        DefaultTableModel model = (DefaultTableModel) jTable1Lop.getModel();
        model.setRowCount(0);
        
        // Lấy dữ liệu từng dòng và thêm vào model
        while (rs.next()) {
            String maLop = rs.getString("MaLop");
            String tenLop = rs.getString("TenLop");
            String tenCN = rs.getString("TenCN");
            String maKhoaHoc = rs.getString("MaKhoaHoc");
            
            Object[] row = { maLop, tenLop, tenCN, maKhoaHoc };
            model.addRow(row);
        }
        
        // Đóng ResultSet, PreparedStatement và Connection
        rs.close();
        pst.close();
        conn.close();
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "❌ Lỗi khi tìm kiếm: " + e.getMessage());
    }
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6TimKiemActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LopHoc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LopHoc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LopHoc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LopHoc.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LopHoc().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton HienThi;
    private javax.swing.JButton jButton2xoa;
    private javax.swing.JButton jButton3sua;
    private javax.swing.JButton jButton4Them;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6TimKiem;
    private javax.swing.JComboBox<String> jComboBox1CN;
    private javax.swing.JComboBox<String> jComboBox2MaKhoaHoc;
    private javax.swing.JComboBox<String> jComboBox4CN;
    private javax.swing.JComboBox<String> jComboBox5KhoaHoc;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1Lop;
    private javax.swing.JTextPane jTextPane1;
    private javax.swing.JTextPane jTextPane2;
    // End of variables declaration//GEN-END:variables
private void icon() {
    
    ImageIcon iconGoc2 = new ImageIcon(getClass().getResource("/Style/add.png"));
    Image iconThuNho2 = iconGoc2.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton4Them.setIcon(new ImageIcon(iconThuNho2));
    jButton4Them.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton4Them.setIconTextGap(5);

    ImageIcon iconGoc3 = new ImageIcon(getClass().getResource("/Style/trash.png"));
    Image iconThuNho3 = iconGoc3.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton2xoa.setIcon(new ImageIcon(iconThuNho3));
    jButton2xoa.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton2xoa.setIconTextGap(5);

            
    ImageIcon iconGoc4 = new ImageIcon(getClass().getResource("/Style/display-code.png"));
    Image iconThuNho4 = iconGoc4.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    HienThi.setIcon(new ImageIcon(iconThuNho4));
    HienThi.setHorizontalTextPosition(SwingConstants.RIGHT);
    HienThi.setIconTextGap(5);
           
            
    ImageIcon iconGoc5 = new ImageIcon(getClass().getResource("/Style/fix.png"));
    Image iconThuNho5 = iconGoc5.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton3sua.setIcon(new ImageIcon(iconThuNho5));
    jButton3sua.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton3sua.setIconTextGap(5);
    
    
    ImageIcon iconGoc6 = new ImageIcon(getClass().getResource("/Style/search.png"));
    Image iconThuNho6 = iconGoc6.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton6TimKiem.setIcon(new ImageIcon(iconThuNho6));
    jButton6TimKiem.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton6TimKiem.setIconTextGap(5);
    
    ImageIcon iconGoc7 = new ImageIcon(getClass().getResource("/Style/reset.png"));
    Image iconThuNho7 = iconGoc7.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH);
    jButton5.setIcon(new ImageIcon(iconThuNho7));
    jButton5.setHorizontalTextPosition(SwingConstants.RIGHT);
    jButton5.setIconTextGap(5);
    
}
private void tuyChinhGiaoDien() {
    // Đặt màu nền nếu bạn muốn giao diện đồng bộ
    this.getContentPane().setBackground(Color.decode("#F5F5FA"));
}
}
