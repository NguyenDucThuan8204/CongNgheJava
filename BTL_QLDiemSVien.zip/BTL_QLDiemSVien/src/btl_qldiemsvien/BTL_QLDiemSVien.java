package btl_qldiemsvien;

import GiaoDien.DangNhap; // Import form đăng nhập

public class BTL_QLDiemSVien {
    public static void main(String[] args) {
        // Khởi động giao diện đăng nhập
        DangNhap formDangNhap = new DangNhap();
        formDangNhap.setVisible(true);
    }
}