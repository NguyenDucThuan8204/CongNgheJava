/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Style;
import com.formdev.flatlaf.FlatLightLaf;
import java.awt.Color;
import java.awt.Font;
import javax.swing.UIManager;
/**
 *
 * @author HoangKy
 */
public class GiaoDienMacDinh {
    public static void caiDatFlatLaf() {
        try {
            // Cài đặt giao diện FlatLightLaf
            UIManager.setLookAndFeel(new FlatLightLaf());

            // Cài đặt phông chữ mặc định
            UIManager.put("defaultFont", new Font("Segoe UI", Font.PLAIN, 14));
            UIManager.put("Label.font", new Font("Segoe UI", Font.BOLD, 12));
            UIManager.put("TextField.font", new Font("Segoe UI", Font.PLAIN, 12));
            UIManager.put("Button.font", new Font("Segoe UI", Font.PLAIN, 12));

            // Cài đặt màu nền mặc định (toàn app)
            UIManager.put("Panel.background", Color.WHITE);
            UIManager.put("Button.background", new Color(230, 230, 250)); // tím nhạt
            UIManager.put("TextField.background", Color.WHITE);
            UIManager.put("Table.background", Color.WHITE);
            UIManager.put("ScrollPane.background", Color.WHITE);

        } catch (Exception e) {
            System.err.println("Lỗi khi thiết lập giao diện FlatLaf: " + e.getMessage());
        }
    }
}
